var __defProp = Object.defineProperty;
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, { get: all[name], enumerable: true });
};

// server/index.ts
import express2 from "express";

// server/routes.ts
import { createServer } from "http";

// server/storage-clean.ts
var MemStorage = class {
  users;
  searchQueries;
  findings;
  removalSteps;
  userIdCounter;
  searchIdCounter;
  findingIdCounter;
  stepIdCounter;
  constructor() {
    this.users = /* @__PURE__ */ new Map();
    this.searchQueries = /* @__PURE__ */ new Map();
    this.findings = /* @__PURE__ */ new Map();
    this.removalSteps = /* @__PURE__ */ new Map();
    this.userIdCounter = 2;
    this.searchIdCounter = 1;
    this.findingIdCounter = 1;
    this.stepIdCounter = 1;
    const adminUser = {
      id: 1,
      username: "rulenumbr1",
      email: "rulenumbr1@icloud.com",
      password: "Y0umissed!",
      hasPaid: true,
      isAdmin: true,
      isSuspended: false,
      stripeCustomerId: "",
      stripePaymentIntentId: "",
      createdAt: /* @__PURE__ */ new Date(),
      paidAt: /* @__PURE__ */ new Date()
    };
    this.users.set(1, adminUser);
  }
  async getUser(id) {
    return this.users.get(id);
  }
  async getUserByUsername(username) {
    const searchTerm = username.toLowerCase();
    return Array.from(this.users.values()).find(
      (user) => user.username.toLowerCase() === searchTerm || user.email.toLowerCase() === searchTerm
    );
  }
  async createUser(insertUser) {
    const id = this.userIdCounter++;
    const user = {
      ...insertUser,
      id,
      createdAt: /* @__PURE__ */ new Date(),
      hasPaid: false,
      stripeCustomerId: null,
      stripePaymentIntentId: null,
      paidAt: null,
      isAdmin: false,
      isSuspended: false
    };
    this.users.set(id, user);
    return user;
  }
  async updateUserPayment(userId, paymentData) {
    const user = this.users.get(userId);
    if (!user) {
      throw new Error("User not found");
    }
    user.stripeCustomerId = paymentData.stripeCustomerId;
    user.stripePaymentIntentId = paymentData.stripePaymentIntentId;
    this.users.set(userId, user);
    return user;
  }
  async markUserAsPaid(userId) {
    const user = this.users.get(userId);
    if (!user) {
      throw new Error("User not found");
    }
    user.hasPaid = true;
    user.paidAt = /* @__PURE__ */ new Date();
    this.users.set(userId, user);
    return user;
  }
  async getSearchCount(userId) {
    return Array.from(this.searchQueries.values()).filter((q) => q.userId === userId).length;
  }
  async createSearchQuery(data) {
    const id = this.searchIdCounter++;
    const searchQuery = {
      ...data,
      id,
      createdAt: /* @__PURE__ */ new Date()
    };
    this.searchQueries.set(id, searchQuery);
    return searchQuery;
  }
  async simulateFindings(searchId) {
    const demoSites = [
      { name: "WhitePages", url: "whitepages.com", risk: "High" },
      { name: "Spokeo", url: "spokeo.com", risk: "Medium" },
      { name: "BeenVerified", url: "beenverified.com", risk: "High" }
    ];
    for (const site of demoSites) {
      const finding = {
        id: this.findingIdCounter++,
        searchId,
        website: site.name,
        websiteUrl: `https://${site.url}`,
        removalUrl: `https://${site.url}/opt-out`,
        riskLevel: site.risk,
        status: "Not Started",
        exposedInfo: ["Name", "Address", "Phone"],
        foundDate: /* @__PURE__ */ new Date(),
        progress: 0,
        currentStep: 1,
        totalSteps: 3
      };
      this.findings.set(finding.id, finding);
    }
  }
  async getFindings() {
    return Array.from(this.findings.values());
  }
  async getRedactedFindings() {
    const findings2 = Array.from(this.findings.values());
    return {
      count: findings2.length,
      privacyScore: findings2.length > 0 ? Math.max(0, 100 - findings2.length * 10) : 100
    };
  }
  async getRemovalGuide(id) {
    const finding = this.findings.get(id);
    if (!finding) return void 0;
    return {
      ...finding,
      steps: [
        { id: 1, title: "Visit removal page", description: "Go to the website's opt-out page", isCompleted: false },
        { id: 2, title: "Submit request", description: "Fill out the removal form", isCompleted: false },
        { id: 3, title: "Verify removal", description: "Confirm your information was removed", isCompleted: false }
      ]
    };
  }
  async updateRemovalStep(id, completed) {
  }
  async updateFindingProgress(findingId) {
  }
  async getDashboard() {
    const findings2 = Array.from(this.findings.values());
    const sitesFound = findings2.length;
    const inProgress = findings2.filter((f) => f.status === "In Progress").length;
    const removed = findings2.filter((f) => f.status === "Complete").length;
    let privacyScore = 100;
    if (sitesFound > 0) {
      privacyScore = Math.round(removed / sitesFound * 100);
    }
    return {
      privacyScore,
      sitesFound,
      inProgress,
      removed,
      lastUpdated: (/* @__PURE__ */ new Date()).toISOString()
    };
  }
  async getAllUsers() {
    return Array.from(this.users.values());
  }
  async suspendUser(userId) {
    const user = this.users.get(userId);
    if (!user) {
      throw new Error("User not found");
    }
    user.isSuspended = true;
    this.users.set(userId, user);
    return user;
  }
  async deleteUser(userId) {
    this.users.delete(userId);
  }
  async getAppSetting(key) {
    if (key === "price") {
      return "13.99";
    }
    return void 0;
  }
  async updateAppSetting(key, value) {
    console.log(`App setting updated: ${key} = ${value}`);
  }
};
var storage = new MemStorage();

// shared/schema.ts
var schema_exports = {};
__export(schema_exports, {
  appSettings: () => appSettings,
  findings: () => findings,
  insertFindingSchema: () => insertFindingSchema,
  insertRemovalStepSchema: () => insertRemovalStepSchema,
  insertSearchQuerySchema: () => insertSearchQuerySchema,
  insertUserSchema: () => insertUserSchema,
  loginSchema: () => loginSchema,
  registerSchema: () => registerSchema,
  removalSteps: () => removalSteps,
  searchQueries: () => searchQueries,
  sessions: () => sessions,
  users: () => users
});
import { pgTable, text, serial, integer, boolean, jsonb, timestamp, varchar, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
var sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull()
  },
  (table) => [index("IDX_session_expire").on(table.expire)]
);
var users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  hasPaid: boolean("has_paid").default(false),
  stripeCustomerId: text("stripe_customer_id"),
  stripePaymentIntentId: text("stripe_payment_intent_id"),
  paidAt: timestamp("paid_at"),
  isAdmin: boolean("is_admin").default(false),
  isSuspended: boolean("is_suspended").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull()
});
var appSettings = pgTable("app_settings", {
  id: serial("id").primaryKey(),
  key: text("key").notNull().unique(),
  value: text("value").notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull()
});
var searchQueries = pgTable("search_queries", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => users.id),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  age: text("age").notNull().default(""),
  email: text("email").notNull().default(""),
  city: text("city").notNull().default(""),
  state: text("state").notNull().default(""),
  createdAt: timestamp("created_at").defaultNow().notNull()
});
var findings = pgTable("findings", {
  id: serial("id").primaryKey(),
  searchId: integer("search_id").notNull().references(() => searchQueries.id),
  website: text("website").notNull(),
  websiteUrl: text("website_url").notNull(),
  removalUrl: text("removal_url").notNull(),
  removalEmail: text("removal_email"),
  riskLevel: text("risk_level").notNull(),
  status: text("status").notNull(),
  exposedInfo: jsonb("exposed_info").notNull(),
  foundDate: text("found_date").notNull(),
  progress: integer("progress").notNull().default(0),
  currentStep: integer("current_step"),
  totalSteps: integer("total_steps"),
  scrubStatus: text("scrub_status").default("pending"),
  // pending, processing, success, failed
  scrubRequestedAt: text("scrub_requested_at"),
  scrubCompletedAt: text("scrub_completed_at"),
  scrubError: text("scrub_error")
});
var removalSteps = pgTable("removal_steps", {
  id: serial("id").primaryKey(),
  findingId: integer("finding_id").notNull().references(() => findings.id),
  title: text("title").notNull(),
  description: text("description").notNull(),
  orderIndex: integer("order_index").notNull(),
  isCompleted: boolean("is_completed").notNull().default(false)
});
var insertUserSchema = createInsertSchema(users).pick({
  username: true,
  email: true,
  password: true
});
var loginSchema = z.object({
  email: z.string().min(1, "Username or email is required"),
  password: z.string().min(6, "Password must be at least 6 characters")
});
var registerSchema = z.object({
  username: z.string().min(3, "Username must be at least 3 characters"),
  email: z.string().email("Please enter a valid email address"),
  password: z.string().min(6, "Password must be at least 6 characters"),
  confirmPassword: z.string()
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords do not match",
  path: ["confirmPassword"]
});
var insertSearchQuerySchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  age: z.string().optional(),
  email: z.string().optional(),
  city: z.string().optional(),
  state: z.string().optional()
});
var insertFindingSchema = createInsertSchema(findings).omit({
  id: true
});
var insertRemovalStepSchema = createInsertSchema(removalSteps).omit({
  id: true
});

// server/routes.ts
import { z as z2 } from "zod";
import { fromZodError } from "zod-validation-error";

// server/auth.ts
import session from "express-session";
import bcrypt from "bcryptjs";

// server/db.ts
import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";
var pool = new Pool({
  connectionString: process.env.DATABASE_URL
});
pool.query("SELECT NOW()", (err, res) => {
  if (err) {
    console.error("Database connection error:", err.message);
  } else {
    console.log("Database connected successfully at", res.rows[0].now);
  }
});
var db = drizzle(pool, { schema: schema_exports });

// server/auth.ts
import { eq } from "drizzle-orm";
var configureAuth = (app2) => {
  app2.use(
    session({
      secret: process.env.SESSION_SECRET || "privacy-scrub-secret",
      resave: false,
      saveUninitialized: false,
      cookie: {
        maxAge: 30 * 24 * 60 * 60 * 1e3,
        // 30 days
        secure: false,
        // Set to false for development
        httpOnly: true
      }
    })
  );
  app2.use((req, res, next) => {
    req.user = req.session.user || null;
    next();
  });
};
var isAuthenticated = (req, res, next) => {
  if (req.session?.user) {
    req.user = req.session.user;
    next();
  } else {
    res.status(401).json({ message: "Unauthorized" });
  }
};
var authService = {
  // Register new user
  async register(userData) {
    try {
      const existingUser = await db.select().from(users).where(eq(users.email, userData.email)).limit(1);
      if (existingUser.length > 0) {
        throw new Error("User with this email already exists");
      }
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(userData.password, salt);
      const [newUser] = await db.insert(users).values({
        username: userData.username,
        email: userData.email,
        password: hashedPassword
      }).returning({ id: users.id, username: users.username, email: users.email });
      return newUser;
    } catch (error) {
      throw new Error(error.message || "Failed to register user");
    }
  },
  // Login user
  async login(credentials) {
    try {
      const [user] = await db.select().from(users).where(eq(users.email, credentials.email)).limit(1);
      if (!user) {
        throw new Error("Invalid credentials");
      }
      const isMatch = await bcrypt.compare(credentials.password, user.password);
      if (!isMatch) {
        throw new Error("Invalid credentials");
      }
      const { password, ...userWithoutPassword } = user;
      return userWithoutPassword;
    } catch (error) {
      throw new Error(error.message || "Failed to login");
    }
  },
  // Update user profile
  async updateProfile(userId, profileData) {
    try {
      const [updatedUser] = await db.update(users).set({
        username: profileData.username,
        email: profileData.email
      }).where(eq(users.id, userId)).returning({ id: users.id, username: users.username, email: users.email });
      if (!updatedUser) {
        throw new Error("User not found");
      }
      return updatedUser;
    } catch (error) {
      throw new Error(error.message || "Failed to update profile");
    }
  },
  // Update user password
  async updatePassword(userId, currentPassword, newPassword) {
    try {
      const [user] = await db.select().from(users).where(eq(users.id, userId)).limit(1);
      if (!user) {
        throw new Error("User not found");
      }
      const isMatch = await bcrypt.compare(currentPassword, user.password);
      if (!isMatch) {
        throw new Error("Current password is incorrect");
      }
      const salt = await bcrypt.genSalt(10);
      const hashedPassword = await bcrypt.hash(newPassword, salt);
      await db.update(users).set({
        password: hashedPassword
      }).where(eq(users.id, userId));
    } catch (error) {
      throw new Error(error.message || "Failed to update password");
    }
  }
};

// server/routes.ts
import Stripe from "stripe";
if (!process.env.STRIPE_SECRET_KEY) {
  throw new Error("Missing required Stripe secret: STRIPE_SECRET_KEY");
}
var stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: "2025-04-30.basil"
});
async function registerRoutes(app2) {
  configureAuth(app2);
  app2.post("/api/auth/register", async (req, res) => {
    try {
      const validatedData = registerSchema.parse(req.body);
      const existingUser = await storage.getUserByUsername(validatedData.email);
      if (existingUser) {
        return res.status(400).json({ message: "User with this email already exists" });
      }
      const user = await storage.createUser({
        username: validatedData.username,
        email: validatedData.email,
        password: validatedData.password
      });
      req.session.user = user;
      res.status(201).json({
        success: true,
        user: { id: user.id, username: user.username, email: user.email, isAdmin: user.isAdmin, hasPaid: user.hasPaid }
      });
    } catch (error) {
      if (error instanceof z2.ZodError) {
        const readableError = fromZodError(error);
        res.status(400).json({ message: "Invalid registration data", error: readableError });
      } else {
        res.status(500).json({ message: error.message || "Failed to register" });
      }
    }
  });
  app2.post("/api/auth/login", async (req, res) => {
    try {
      console.log("Login attempt with:", JSON.stringify(req.body));
      const validatedData = loginSchema.parse(req.body);
      console.log("Validation passed:", JSON.stringify(validatedData));
      const user = await storage.getUserByUsername(validatedData.email.toLowerCase());
      console.log("User found:", user ? "Yes" : "No");
      if (!user || user.password !== validatedData.password) {
        console.log("Password match:", user ? user.password === validatedData.password : "No user");
        return res.status(401).json({ message: "Invalid credentials" });
      }
      req.session.user = user;
      req.session.save((err) => {
        if (err) {
          console.error("Session save error:", err);
          return res.status(500).json({ message: "Session error" });
        }
        res.json({
          success: true,
          user: { id: user.id, username: user.username, email: user.email, isAdmin: user.isAdmin, hasPaid: user.hasPaid }
        });
      });
    } catch (error) {
      console.log("Login error:", error);
      if (error instanceof z2.ZodError) {
        const readableError = fromZodError(error);
        console.log("Validation error details:", readableError);
        res.status(400).json({ message: "Invalid login data", error: readableError });
      } else {
        res.status(401).json({ message: error.message || "Authentication failed" });
      }
    }
  });
  app2.post("/api/auth/logout", (req, res) => {
    req.session.destroy((err) => {
      if (err) {
        return res.status(500).json({ message: "Failed to logout" });
      }
      res.json({ success: true });
    });
  });
  app2.get("/api/auth/me", (req, res) => {
    const user = req.session?.user;
    if (user) {
      res.json({ id: user.id, username: user.username, email: user.email, isAdmin: user.isAdmin, hasPaid: user.hasPaid });
    } else {
      res.status(401).json({ message: "Not authenticated" });
    }
  });
  app2.patch("/api/auth/profile", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const { username, email } = req.body;
      if (!username || !email) {
        return res.status(400).json({ message: "Username and email are required" });
      }
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser && existingUser.id !== userId) {
        return res.status(400).json({ message: "Username already taken" });
      }
      const updatedUser = await authService.updateProfile(userId, { username, email });
      req.session.user = updatedUser;
      res.json({ success: true, user: updatedUser });
    } catch (error) {
      res.status(500).json({ message: error.message || "Failed to update profile" });
    }
  });
  app2.patch("/api/auth/password", isAuthenticated, async (req, res) => {
    try {
      const userId = req.user.claims.sub;
      const { currentPassword, newPassword } = req.body;
      if (!currentPassword || !newPassword) {
        return res.status(400).json({ message: "Current password and new password are required" });
      }
      await authService.updatePassword(userId, currentPassword, newPassword);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: error.message || "Failed to update password" });
    }
  });
  app2.post("/api/create-payment-intent", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      if (user.hasPaid) {
        return res.status(400).json({ message: "User has already paid for full access" });
      }
      const paymentIntent = await stripe.paymentIntents.create({
        amount: 1399,
        // $13.99 in cents
        currency: "usd",
        metadata: {
          userId: user.id.toString()
        }
      });
      await storage.updateUserPayment(user.id, {
        stripeCustomerId: paymentIntent.customer || "",
        stripePaymentIntentId: paymentIntent.id
      });
      res.json({ clientSecret: paymentIntent.client_secret });
    } catch (error) {
      console.error("Error creating payment intent:", error);
      res.status(500).json({ message: "Error creating payment intent: " + error.message });
    }
  });
  app2.post("/api/confirm-payment", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      const { paymentIntentId } = req.body;
      const paymentIntent = await stripe.paymentIntents.retrieve(paymentIntentId);
      if (paymentIntent.status === "succeeded" && paymentIntent.metadata.userId === user.id.toString()) {
        await storage.markUserAsPaid(user.id);
        res.json({ success: true, message: "Payment confirmed! You now have full access." });
      } else {
        res.status(400).json({ message: "Payment verification failed" });
      }
    } catch (error) {
      console.error("Error confirming payment:", error);
      res.status(500).json({ message: "Error confirming payment: " + error.message });
    }
  });
  const isAdmin = (req, res, next) => {
    if (!req.user || !req.user.isAdmin) {
      return res.status(403).json({ message: "Admin access required" });
    }
    next();
  };
  app2.get("/api/admin/users", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const users2 = await storage.getAllUsers();
      res.json(users2);
    } catch (error) {
      console.error("Error fetching users:", error);
      res.status(500).json({ message: "Failed to fetch users" });
    }
  });
  app2.get("/api/admin/price", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const priceCents = await storage.getAppSetting("price_cents") || "1399";
      const priceDisplay = (parseInt(priceCents) / 100).toFixed(2);
      res.json(priceDisplay);
    } catch (error) {
      console.error("Error fetching price:", error);
      res.status(500).json({ message: "Failed to fetch price" });
    }
  });
  app2.post("/api/admin/price", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const { price } = req.body;
      const priceCents = Math.round(parseFloat(price) * 100).toString();
      await storage.updateAppSetting("price_cents", priceCents);
      res.json({ success: true, message: "Price updated successfully" });
    } catch (error) {
      console.error("Error updating price:", error);
      res.status(500).json({ message: "Failed to update price" });
    }
  });
  app2.post("/api/admin/users/:id/suspend", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      const user = await storage.suspendUser(userId);
      res.json({ success: true, user });
    } catch (error) {
      console.error("Error suspending user:", error);
      res.status(500).json({ message: "Failed to suspend user" });
    }
  });
  app2.delete("/api/admin/users/:id", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const userId = parseInt(req.params.id);
      await storage.deleteUser(userId);
      res.json({ success: true, message: "User deleted successfully" });
    } catch (error) {
      console.error("Error deleting user:", error);
      res.status(500).json({ message: "Failed to delete user" });
    }
  });
  app2.post("/api/admin/users/create-paid", isAuthenticated, isAdmin, async (req, res) => {
    try {
      const { username, email, password } = req.body;
      if (!username || !email || !password) {
        return res.status(400).json({ message: "Username, email, and password are required" });
      }
      const existingUser = await storage.getUserByUsername(username);
      if (existingUser) {
        return res.status(400).json({ message: "User with this username already exists" });
      }
      const newUser = await storage.createUser({
        username,
        email,
        password
      });
      const paidUser = await storage.markUserAsPaid(newUser.id);
      res.json({ success: true, user: paidUser, message: "Paid account created successfully" });
    } catch (error) {
      console.error("Error creating paid account:", error);
      res.status(500).json({ message: "Failed to create paid account" });
    }
  });
  app2.get("/api/dashboard", async (_req, res) => {
    try {
      const dashboard = await storage.getDashboard();
      res.json(dashboard);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch dashboard data" });
    }
  });
  app2.post("/api/search", isAuthenticated, async (req, res) => {
    try {
      const validatedData = insertSearchQuerySchema.parse(req.body);
      const user = req.user;
      const existingSearches = await storage.getSearchCount(user.id);
      if (existingSearches >= 1 && !user.hasPaid) {
        return res.status(402).json({
          message: "Payment required for additional searches",
          requiresPayment: true
        });
      }
      console.log("Search data:", validatedData);
      const searchQuery = await storage.createSearchQuery({
        ...validatedData,
        userId: user.id
      });
      await storage.simulateFindings(searchQuery.id);
      res.status(201).json({ success: true, searchId: searchQuery.id });
    } catch (error) {
      console.error("Search error:", error);
      if (error instanceof z2.ZodError) {
        const readableError = fromZodError(error);
        res.status(400).json({ message: "Invalid search data", error: readableError });
      } else {
        res.status(500).json({ message: "Failed to create search", error: error.message });
      }
    }
  });
  app2.get("/api/findings", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      if (user.hasPaid) {
        const findings2 = await storage.getFindings();
        res.json(findings2);
      } else {
        const redactedData = await storage.getRedactedFindings();
        res.json({
          isRedacted: true,
          sitesFound: redactedData.count,
          privacyScore: redactedData.privacyScore,
          message: "Upgrade to see detailed findings and removal guides"
        });
      }
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch findings" });
    }
  });
  app2.get("/api/removal-guides/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const guide = await storage.getRemovalGuide(id);
      if (!guide) {
        return res.status(404).json({ message: "Removal guide not found" });
      }
      res.json(guide);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch removal guide" });
    }
  });
  app2.post("/api/removal-guides/:findingId/steps/:stepId", async (req, res) => {
    try {
      const findingId = parseInt(req.params.findingId);
      const stepId = parseInt(req.params.stepId);
      const { completed } = req.body;
      if (typeof completed !== "boolean") {
        return res.status(400).json({ message: "Invalid request body" });
      }
      await storage.updateRemovalStep(stepId, completed);
      await storage.updateFindingProgress(findingId);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ message: "Failed to update step" });
    }
  });
  app2.post("/api/scrub/initiate", isAuthenticated, async (req, res) => {
    try {
      const user = req.user;
      if (!user.hasPaid) {
        return res.status(403).json({
          success: false,
          message: "Data removal is only available for paid accounts"
        });
      }
      const findings2 = await storage.getFindings();
      if (findings2.length === 0) {
        return res.status(400).json({
          success: false,
          message: "No data findings to remove. Complete a search first."
        });
      }
      setTimeout(() => {
        findings2.forEach((finding, index2) => {
          setTimeout(async () => {
            try {
              const storageFindingsMap = storage.findings;
              if (storageFindingsMap && storageFindingsMap.has(finding.id)) {
                const storedFinding = storageFindingsMap.get(finding.id);
                storedFinding.status = "Complete";
                storedFinding.progress = 100;
                storageFindingsMap.set(finding.id, storedFinding);
                console.log(`Automated removal completed for ${finding.website}`);
              }
            } catch (error) {
              console.error(`Failed to update finding ${finding.id}:`, error);
            }
          }, (index2 + 1) * 2e3);
        });
      }, 1e3);
      res.json({
        success: true,
        message: `Started automated removal process for ${findings2.length} data findings`,
        totalSites: findings2.length
      });
    } catch (error) {
      console.error("Error initiating scrub process:", error);
      res.status(500).json({
        message: "Failed to initiate data removal",
        error: error.message
      });
    }
  });
  const httpServer = createServer(app2);
  return httpServer;
}

// server/vite.ts
import express from "express";
import fs from "fs";
import path2 from "path";
import { createServer as createViteServer, createLogger } from "vite";

// vite.config.ts
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import path from "path";
import runtimeErrorOverlay from "@replit/vite-plugin-runtime-error-modal";
var vite_config_default = defineConfig({
  plugins: [
    react(),
    runtimeErrorOverlay(),
    ...process.env.NODE_ENV !== "production" && process.env.REPL_ID !== void 0 ? [
      await import("@replit/vite-plugin-cartographer").then(
        (m) => m.cartographer()
      )
    ] : []
  ],
  resolve: {
    alias: {
      "@": path.resolve(import.meta.dirname, "client", "src"),
      "@shared": path.resolve(import.meta.dirname, "shared"),
      "@assets": path.resolve(import.meta.dirname, "attached_assets")
    }
  },
  root: path.resolve(import.meta.dirname, "client"),
  build: {
    outDir: path.resolve(import.meta.dirname, "dist/public"),
    emptyOutDir: true
  },
  server: {
    hmr: {
      overlay: false
    }
  }
});

// server/vite.ts
import { nanoid } from "nanoid";
var viteLogger = createLogger();
function log(message, source = "express") {
  const formattedTime = (/* @__PURE__ */ new Date()).toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    second: "2-digit",
    hour12: true
  });
  console.log(`${formattedTime} [${source}] ${message}`);
}
async function setupVite(app2, server) {
  const serverOptions = {
    middlewareMode: true,
    hmr: { server },
    allowedHosts: true
  };
  const vite = await createViteServer({
    ...vite_config_default,
    configFile: false,
    customLogger: {
      ...viteLogger,
      error: (msg, options) => {
        viteLogger.error(msg, options);
        process.exit(1);
      }
    },
    server: serverOptions,
    appType: "custom"
  });
  app2.use(vite.middlewares);
  app2.use("*", async (req, res, next) => {
    const url = req.originalUrl;
    try {
      const clientTemplate = path2.resolve(
        import.meta.dirname,
        "..",
        "client",
        "index.html"
      );
      let template = await fs.promises.readFile(clientTemplate, "utf-8");
      template = template.replace(
        `src="/src/main.tsx"`,
        `src="/src/main.tsx?v=${nanoid()}"`
      );
      const page = await vite.transformIndexHtml(url, template);
      res.status(200).set({ "Content-Type": "text/html" }).end(page);
    } catch (e) {
      vite.ssrFixStacktrace(e);
      next(e);
    }
  });
}
function serveStatic(app2) {
  const distPath = path2.resolve(import.meta.dirname, "public");
  if (!fs.existsSync(distPath)) {
    throw new Error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`
    );
  }
  app2.use(express.static(distPath));
  app2.use("*", (_req, res) => {
    res.sendFile(path2.resolve(distPath, "index.html"));
  });
}

// server/index.ts
var app = express2();
app.use(express2.json());
app.use(express2.urlencoded({ extended: false }));
app.use((req, res, next) => {
  const start = Date.now();
  const path3 = req.path;
  let capturedJsonResponse = void 0;
  const originalResJson = res.json;
  res.json = function(bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };
  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path3.startsWith("/api")) {
      let logLine = `${req.method} ${path3} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }
      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "\u2026";
      }
      log(logLine);
    }
  });
  next();
});
(async () => {
  const server = await registerRoutes(app);
  app.use((err, _req, res, _next) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";
    res.status(status).json({ message });
    throw err;
  });
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }
  const port = 5e3;
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true
  }, () => {
    log(`serving on port ${port}`);
  });
})();
