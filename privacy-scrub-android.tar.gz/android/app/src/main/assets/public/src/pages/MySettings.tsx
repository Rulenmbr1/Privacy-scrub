import { useState } from "react";
import { useAuth } from "@/hooks/AuthProvider";
import { useToast } from "@/hooks/use-toast";

const MySettings = () => {
  const { user, logout } = useAuth();
  const { toast } = useToast();
  const [showConfirmLogout, setShowConfirmLogout] = useState(false);
  
  const handleLogout = () => {
    logout();
    toast({
      title: "Logged out",
      description: "You have been successfully logged out."
    });
  };
  
  return (
    <div className="container mx-auto py-8 max-w-4xl">
      <h1 className="text-2xl font-bold mb-6">Account Settings</h1>
      
      <div className="bg-card rounded-xl p-6 shadow-sm mb-6">
        <h2 className="text-xl font-semibold mb-4">Profile Information</h2>
        <div className="space-y-4">
          <div>
            <p className="text-sm font-medium text-muted-foreground">Username</p>
            <p className="text-foreground font-medium">{user?.username || "Loading..."}</p>
          </div>
          
          <div>
            <p className="text-sm font-medium text-muted-foreground">Email</p>
            <p className="text-foreground font-medium">{user?.email || "Loading..."}</p>
          </div>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-card rounded-xl p-6 shadow-sm">
          <h2 className="text-xl font-semibold mb-4">Privacy Controls</h2>
          <p className="text-muted-foreground mb-4">
            Manage what personal information is visible and how your data is used.
          </p>
          <button
            type="button"
            className="w-full py-2 rounded-md bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
            onClick={() => {
              toast({
                title: "Coming Soon",
                description: "This feature will be available in a future update."
              });
            }}
          >
            Privacy Settings
          </button>
        </div>
        
        <div className="bg-card rounded-xl p-6 shadow-sm">
          <h2 className="text-xl font-semibold mb-4">Security</h2>
          <p className="text-muted-foreground mb-4">
            Change your password and manage account security settings.
          </p>
          <button
            type="button"
            className="w-full py-2 rounded-md bg-primary text-primary-foreground hover:bg-primary/90 transition-colors"
            onClick={() => {
              toast({
                title: "Coming Soon",
                description: "Password change functionality will be available in a future update."
              });
            }}
          >
            Security Settings
          </button>
        </div>
      </div>

      <div className="mt-8 bg-card rounded-xl p-6 shadow-sm">
        <h2 className="text-xl font-semibold mb-4">Account Actions</h2>
        
        {!showConfirmLogout ? (
          <button 
            type="button"
            className="py-2 px-4 rounded-md bg-destructive text-destructive-foreground hover:bg-destructive/90 transition-colors"
            onClick={() => setShowConfirmLogout(true)}
          >
            Log Out
          </button>
        ) : (
          <div className="bg-destructive/10 p-4 rounded-md">
            <p className="mb-4 font-medium">Are you sure you want to log out?</p>
            <div className="flex space-x-2">
              <button 
                type="button"
                className="py-2 px-4 rounded-md bg-destructive text-destructive-foreground hover:bg-destructive/90 transition-colors"
                onClick={handleLogout}
              >
                Yes, Log Out
              </button>
              <button 
                type="button"
                className="py-2 px-4 rounded-md bg-secondary text-secondary-foreground hover:bg-secondary/90 transition-colors"
                onClick={() => setShowConfirmLogout(false)}
              >
                Cancel
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default MySettings;