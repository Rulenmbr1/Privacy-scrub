import { useQuery } from "@tanstack/react-query";
import PrivacyScoreCard from "@/components/dashboard/PrivacyScoreCard";
import SearchSection from "@/components/dashboard/SearchSection";
import RecentFindings from "@/components/dashboard/RecentFindings";
import RemovalGuide from "@/components/dashboard/RemovalGuide";
import AppLayout from "@/components/layout/AppLayout";
import { Button } from "@/components/ui/button";

const Dashboard = () => {
  const { data: dashboardData, isLoading } = useQuery({
    queryKey: ['/api/dashboard'],
  });

  return (
    <AppLayout>
      <div className="py-6">
        <header className="mb-8">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4">
            <div>
              <h1 className="text-2xl font-bold text-dark">Privacy Scrub Dashboard</h1>
              <p className="text-medium mt-1">Monitor and manage your digital privacy</p>
            </div>
            <div className="mt-4 md:mt-0">
              <Button 
                className="bg-blue-600 hover:bg-blue-700 text-white"
                onClick={() => window.location.href = '/new-search'}
              >
                Start New Search
              </Button>
            </div>
          </div>
        </header>

        {isLoading ? (
          <div className="animate-pulse">
            <div className="bg-card rounded-xl shadow-sm mb-6 p-6">
              <div className="h-8 bg-muted rounded w-1/4 mb-4"></div>
              <div className="h-4 bg-muted rounded w-1/2 mb-6"></div>
              <div className="flex flex-col md:flex-row gap-6">
                <div className="bg-muted rounded-lg h-40 w-full md:w-40"></div>
                <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-4">
                  {[...Array(3)].map((_, i) => (
                    <div key={i} className="bg-muted rounded-lg h-24"></div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        ) : (
          <PrivacyScoreCard 
            score={dashboardData?.privacyScore || 0}
            sitesFound={dashboardData?.sitesFound || 0}
            inProgress={dashboardData?.inProgress || 0}
            removed={dashboardData?.removed || 0}
            lastUpdated={dashboardData?.lastUpdated || "Today"}
          />
        )}

        <SearchSection />
        
        <RecentFindings limit={3} />
        
        <RemovalGuide />
        
        <footer className="mt-12 py-6 border-t text-center text-sm text-light">
          <p>© {new Date().getFullYear()} Privacy Scrub. All rights reserved.</p>
        </footer>
      </div>
    </AppLayout>
  );
};

export default Dashboard;
