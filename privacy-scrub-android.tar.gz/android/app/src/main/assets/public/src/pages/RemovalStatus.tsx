import { useQuery } from "@tanstack/react-query";
import { Finding } from "@/components/dashboard/RecentFindings";
import { Link } from "wouter";
import { useState } from "react";

const RemovalStatus = () => {
  const [filter, setFilter] = useState<string>("all");
  const { data: findings, isLoading } = useQuery<Finding[]>({
    queryKey: ['/api/findings'],
  });

  if (isLoading) {
    return (
      <div className="px-4 md:px-8 py-6">
        <header className="mb-8">
          <h1 className="text-2xl font-bold">Removal Status</h1>
          <p className="text-light mt-1">Track your information removal progress</p>
        </header>
        
        <div className="animate-pulse space-y-4">
          {[...Array(5)].map((_, index) => (
            <div key={index} className="bg-white rounded-xl shadow-sm p-6">
              <div className="h-6 bg-gray-200 rounded w-1/3 mb-4"></div>
              <div className="h-4 bg-gray-200 rounded w-1/2 mb-6"></div>
              <div className="space-y-2">
                <div className="h-4 bg-gray-200 rounded"></div>
                <div className="h-4 bg-gray-200 rounded"></div>
                <div className="h-4 bg-gray-200 rounded w-3/4"></div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // Handle both redacted and full findings format
  const findingsArray = Array.isArray(findings) ? findings : [];
  const filteredFindings = findingsArray?.filter(finding => {
    if (filter === "all") return true;
    if (filter === "not-started") return finding.status === "Not Started";
    if (filter === "in-progress") return finding.status === "In Progress";
    if (filter === "complete") return finding.status === "Complete";
    if (filter === "action-needed") return finding.status === "Action Needed";
    return true;
  });

  return (
    <div className="px-4 md:px-8 py-6">
      <header className="mb-8">
        <h1 className="text-2xl font-bold">Removal Status</h1>
        <p className="text-light mt-1">Track your information removal progress</p>
      </header>

      {!findings || findings.length === 0 ? (
        <div className="bg-white rounded-xl shadow-sm p-10 text-center">
          <i className="ri-file-search-line text-5xl text-light mb-4"></i>
          <h2 className="text-xl font-medium mb-2">No findings to display</h2>
          <p className="text-light mb-6">Start a scan to find your personal information across the web</p>
          <Link href="/new-search">
            <a className="px-6 py-3 bg-primary hover:bg-primary-dark text-white font-medium rounded-lg transition-colors shadow-sm inline-flex items-center">
              <i className="ri-search-line mr-2"></i>
              Start a New Scan
            </a>
          </Link>
        </div>
      ) : (
        <>
          <div className="bg-white rounded-xl shadow-sm mb-6 p-4">
            <div className="flex flex-wrap gap-2">
              <button 
                onClick={() => setFilter("all")} 
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  filter === "all" 
                    ? "bg-primary text-white" 
                    : "bg-gray-100 text-medium hover:bg-gray-200"
                }`}
              >
                All ({findingsArray.length})
              </button>
              <button 
                onClick={() => setFilter("not-started")} 
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  filter === "not-started" 
                    ? "bg-primary text-white" 
                    : "bg-gray-100 text-medium hover:bg-gray-200"
                }`}
              >
                Not Started ({findingsArray.filter(f => f.status === "Not Started").length})
              </button>
              <button 
                onClick={() => setFilter("in-progress")} 
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  filter === "in-progress" 
                    ? "bg-primary text-white" 
                    : "bg-gray-100 text-medium hover:bg-gray-200"
                }`}
              >
                In Progress ({findingsArray.filter(f => f.status === "In Progress").length})
              </button>
              <button 
                onClick={() => setFilter("complete")} 
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  filter === "complete" 
                    ? "bg-primary text-white" 
                    : "bg-gray-100 text-medium hover:bg-gray-200"
                }`}
              >
                Complete ({findingsArray.filter(f => f.status === "Complete").length})
              </button>
              <button 
                onClick={() => setFilter("action-needed")} 
                className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                  filter === "action-needed" 
                    ? "bg-primary text-white" 
                    : "bg-gray-100 text-medium hover:bg-gray-200"
                }`}
              >
                Action Needed ({findingsArray.filter(f => f.status === "Action Needed").length})
              </button>
            </div>
          </div>
          
          <div className="space-y-4">
            {filteredFindings && filteredFindings.map((finding) => (
              <div key={finding.id} className="bg-white rounded-xl shadow-sm overflow-hidden">
                <div className="p-5 border-b">
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center">
                        <h3 className="font-semibold">{finding.website}</h3>
                        <span className={`ml-3 px-2 py-1 rounded-md text-xs font-medium 
                          ${finding.riskLevel === 'High' ? 'bg-error bg-opacity-10 text-error' : 
                          finding.riskLevel === 'Medium' ? 'bg-warning bg-opacity-10 text-warning' : 
                          'bg-success bg-opacity-10 text-success'}`}>
                          {finding.riskLevel} Risk
                        </span>
                      </div>
                      <p className="text-light text-sm mt-1">Found {finding.foundDate}</p>
                    </div>
                    <div className="flex items-center">
                      <span className={`px-3 py-1 rounded-full text-xs font-medium flex items-center
                        ${finding.status === 'Complete' ? 'bg-success bg-opacity-10 text-success' : 
                        finding.status === 'In Progress' ? 'bg-warning bg-opacity-10 text-warning' : 
                        finding.status === 'Action Needed' ? 'bg-error bg-opacity-10 text-error' :
                        'bg-error bg-opacity-10 text-error'}`}>
                        <i className={`
                          ${finding.status === 'Complete' ? 'ri-check-line' : 
                          finding.status === 'In Progress' ? 'ri-time-line' : 
                          'ri-error-warning-line'} mr-1`}></i>
                        {finding.status}
                      </span>
                    </div>
                  </div>
                </div>
                
                <div className="px-5 py-4">
                  <h4 className="text-sm font-medium mb-2">Information Exposed:</h4>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm mb-4">
                    {finding.exposedInfo.map((info, index) => (
                      <div key={index} className="flex items-center">
                        <i className="ri-check-line text-error mr-2"></i>
                        <span>{info}</span>
                      </div>
                    ))}
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <div>
                      {finding.status === "Not Started" ? (
                        <Link href={`/removal-guides/${finding.id}`}>
                          <a className="text-primary hover:text-primary-dark text-sm font-medium transition-colors">
                            Start Removal Process
                          </a>
                        </Link>
                      ) : finding.status === "In Progress" ? (
                        <Link href={`/removal-guides/${finding.id}`}>
                          <a className="text-primary hover:text-primary-dark text-sm font-medium transition-colors">
                            View Removal Guide
                          </a>
                        </Link>
                      ) : finding.status === "Action Needed" ? (
                        <Link href={`/removal-guides/${finding.id}`}>
                          <a className="text-primary hover:text-primary-dark text-sm font-medium transition-colors">
                            Take Action
                          </a>
                        </Link>
                      ) : (
                        <Link href={`/removal-guides/${finding.id}`}>
                          <a className="text-primary hover:text-primary-dark text-sm font-medium transition-colors">
                            View Details
                          </a>
                        </Link>
                      )}
                    </div>
                    <div className="space-x-2">
                      {finding.status === "In Progress" ? (
                        <span className="text-light text-sm">
                          Step {finding.currentStep} of {finding.totalSteps}
                        </span>
                      ) : finding.status === "Complete" ? (
                        <span className="text-light text-sm">Completed</span>
                      ) : finding.status === "Not Started" ? (
                        <span className="text-light text-sm">Not Started</span>
                      ) : (
                        <span className="text-light text-sm">Action Required</span>
                      )}
                      <div className="inline-block w-24 h-2 rounded-full bg-gray-200">
                        <div 
                          className={`h-full rounded-full ${
                            finding.progress === 100 ? "bg-success" : 
                            finding.progress > 0 ? "bg-warning" : 
                            "bg-primary"
                          }`} 
                          style={{ width: `${finding.progress}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
};

export default RemovalStatus;
