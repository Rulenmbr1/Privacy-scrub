import { Link } from "wouter";
import { useLocation } from "wouter";

const RemovalGuide = () => {
  return (
    <div className="bg-white rounded-xl shadow-sm mt-8 p-6 border-t-4 border-primary">
      <h2 className="text-lg font-semibold mb-2">Data Removal Process</h2>
      <p className="text-medium text-sm mb-4">Follow these steps to remove your personal information from data brokers.</p>
      
      <div className="space-y-4">
        <div className="flex">
          <div className="flex flex-col items-center mr-4">
            <div className="h-10 w-10 rounded-full bg-primary text-white flex items-center justify-center font-bold">1</div>
            <div className="h-full w-0.5 bg-gray-200 mt-2"></div>
          </div>
          <div className="pb-4">
            <h3 className="font-medium text-base">Search for your information</h3>
            <p className="text-medium text-sm mt-1">Use our tool to scan for your personal details across people-search websites.</p>
          </div>
        </div>
        
        <div className="flex">
          <div className="flex flex-col items-center mr-4">
            <div className="h-10 w-10 rounded-full bg-primary text-white flex items-center justify-center font-bold">2</div>
            <div className="h-full w-0.5 bg-gray-200 mt-2"></div>
          </div>
          <div className="pb-4">
            <h3 className="font-medium text-base">Review found information</h3>
            <p className="text-medium text-sm mt-1">See what personal data is exposed and which sites are publishing it.</p>
          </div>
        </div>
        
        <div className="flex">
          <div className="flex flex-col items-center mr-4">
            <div className="h-10 w-10 rounded-full bg-primary text-white flex items-center justify-center font-bold">3</div>
            <div className="h-full w-0.5 bg-gray-200 mt-2"></div>
          </div>
          <div className="pb-4">
            <h3 className="font-medium text-base">Follow removal guides</h3>
            <p className="text-medium text-sm mt-1">We provide step-by-step instructions for removing data from each site.</p>
          </div>
        </div>
        
        <div className="flex">
          <div className="flex flex-col items-center mr-4">
            <div className="h-10 w-10 rounded-full bg-primary text-white flex items-center justify-center font-bold">4</div>
          </div>
          <div>
            <h3 className="font-medium text-base">Track your progress</h3>
            <p className="text-medium text-sm mt-1">Monitor the status of each removal request until completion.</p>
          </div>
        </div>
      </div>
      
      <div className="mt-6 pt-4 border-t flex flex-col sm:flex-row justify-between items-center">
        <p className="text-sm font-medium mb-4 sm:mb-0">Ready to secure your personal information?</p>
        <button 
          onClick={() => window.location.href = '/new-search'} 
          className="px-5 py-2 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors shadow-sm"
        >
          Start a New Scan
        </button>
      </div>
    </div>
  );
};

export default RemovalGuide;
