export interface User {
  id: number;
  username: string;
}

export interface SearchQuery {
  id: number;
  userId: number;
  firstName: string;
  lastName: string;
  email?: string;
  city?: string;
  state?: string;
  createdAt: string;
}

export interface Finding {
  id: number;
  searchId: number;
  website: string;
  websiteUrl: string;
  removalUrl: string;
  removalEmail?: string;
  riskLevel: "High" | "Medium" | "Low";
  status: "Not Started" | "In Progress" | "Complete" | "Action Needed";
  exposedInfo: string[];
  foundDate: string;
  progress: number;
  currentStep?: number;
  totalSteps?: number;
}

export interface RemovalStep {
  id: number;
  findingId: number;
  title: string;
  description: string;
  orderIndex: number;
  isCompleted: boolean;
}

export interface Dashboard {
  privacyScore: number;
  sitesFound: number;
  inProgress: number;
  removed: number;
  lastUpdated: string;
}
