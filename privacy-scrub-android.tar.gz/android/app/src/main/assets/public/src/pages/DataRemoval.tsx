import { useAuth } from "@/hooks/AuthProvider";
import AppLayout from "@/components/layout/AppLayout";
import { DataScrubber } from "@/components/DataScrubber";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ShieldCheck, CreditCard } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function DataRemoval() {
  const { user } = useAuth();

  if (!user?.hasPaid) {
    return (
      <AppLayout>
        <div className="py-6">
          <header className="mb-8">
            <h1 className="text-2xl font-bold text-dark">Automated Data Removal</h1>
            <p className="text-medium mt-1">Automatically remove your data from websites</p>
          </header>

          <Card className="max-w-2xl mx-auto">
            <CardHeader className="text-center">
              <div className="mx-auto w-16 h-16 bg-blue-100 dark:bg-blue-900/20 rounded-full flex items-center justify-center mb-4">
                <CreditCard className="h-8 w-8 text-blue-600" />
              </div>
              <CardTitle>Premium Feature</CardTitle>
              <CardDescription>
                Automated data removal is available for paid accounts only
              </CardDescription>
            </CardHeader>
            <CardContent className="text-center space-y-6">
              <div className="bg-blue-50 dark:bg-blue-950/20 p-4 rounded-lg">
                <h4 className="font-semibold text-blue-900 dark:text-blue-100 mb-2">
                  What you get with automated removal:
                </h4>
                <ul className="text-sm text-blue-800 dark:text-blue-200 space-y-1 text-left">
                  <li>• One-click removal from all found websites</li>
                  <li>• Automatic retry for failed requests</li>
                  <li>• Real-time progress tracking</li>
                  <li>• Complete removal verification</li>
                </ul>
              </div>
              
              <Button 
                onClick={() => window.location.href = '/checkout'}
                className="w-full bg-blue-600 hover:bg-blue-700"
              >
                Upgrade to Premium
              </Button>
            </CardContent>
          </Card>
        </div>
      </AppLayout>
    );
  }

  return (
    <AppLayout>
      <div className="py-6">
        <header className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <h1 className="text-2xl font-bold text-dark">Automated Data Removal</h1>
            <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
              <ShieldCheck className="mr-1 h-3 w-3" />
              Premium
            </Badge>
          </div>
          <p className="text-medium">
            Remove your personal information from data broker websites automatically
          </p>
        </header>

        <div className="max-w-4xl mx-auto">
          <DataScrubber />
        </div>
      </div>
    </AppLayout>
  );
}