import { Link, useLocation } from "wouter";
import { ThemeToggle } from "../ThemeToggle";

interface NavItemProps {
  href: string;
  icon: string;
  label: string;
  isActive?: boolean;
}

const NavItem = ({ href, icon, label, isActive }: NavItemProps) => {
  return (
    <Link 
      href={href}
      className={`flex items-center space-x-3 px-3 py-3 rounded-lg font-medium transition-colors ${
        isActive
          ? "bg-primary bg-opacity-10 text-primary dark:bg-primary dark:bg-opacity-20"
          : "text-foreground/70 hover:bg-accent hover:text-foreground dark:text-foreground/60 dark:hover:bg-accent"
      }`}
    >
      <i className={`${icon} text-lg`}></i>
      <span>{label}</span>
    </Link>
  );
};

const Sidebar = () => {
  const [location] = useLocation();

  const isActive = (path: string) => {
    return location === path;
  };

  return (
    <>
      <aside className="sidebar bg-card dark:bg-card w-64 fixed h-full shadow-md z-30 hidden md:block border-r">
        <div className="flex flex-col h-full">
          <div className="p-5 border-b flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <i className="ri-shield-check-line text-2xl text-primary"></i>
              <h1 className="text-xl font-bold text-foreground">Privacy Scrub</h1>
            </div>
            <ThemeToggle />
          </div>

          <nav className="flex-1 px-4 pt-4">
            <div className="space-y-1">
              <NavItem
                href="/"
                icon="ri-dashboard-line"
                label="Dashboard"
                isActive={isActive("/")}
              />
              <NavItem
                href="/new-search"
                icon="ri-search-line"
                label="New Search"
                isActive={isActive("/new-search")}
              />
              <NavItem
                href="/removal-status"
                icon="ri-list-check"
                label="Removal Status"
                isActive={isActive("/removal-status")}
              />
              <NavItem
                href="/privacy-settings"
                icon="ri-lock-line"
                label="Privacy Settings"
                isActive={isActive("/privacy-settings")}
              />
            </div>

            <div className="mt-8 pt-8 border-t">
              <div className="space-y-1">
                <NavItem
                  href="/help"
                  icon="ri-question-line"
                  label="Help & Resources"
                  isActive={isActive("/help")}
                />
                <NavItem
                  href="/account-settings"
                  icon="ri-settings-3-line"
                  label="Account Settings"
                  isActive={isActive("/account-settings")}
                />
              </div>
            </div>
          </nav>

          <div className="p-4 border-t">
            <div className="flex items-center space-x-3 px-2">
              <div className="h-10 w-10 rounded-full bg-primary bg-opacity-10 text-primary flex items-center justify-center">
                <i className="ri-user-line"></i>
              </div>
              <div>
                <p className="text-sm font-medium text-foreground">User</p>
                <p className="text-xs text-muted-foreground">user@example.com</p>
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* Mobile Sidebar Toggle */}
      <div className="md:hidden fixed top-4 left-4 z-50">
        <button
          id="openSidebar"
          className="p-2 rounded-lg bg-card dark:bg-card shadow-md text-foreground"
          onClick={() => {
            const sidebar = document.querySelector('.sidebar');
            const overlay = document.getElementById('sidebarOverlay');
            
            if (sidebar && overlay) {
              sidebar.classList.add('active');
              sidebar.classList.remove('hidden');
              overlay.classList.remove('hidden');
              document.body.classList.add('overflow-hidden');
            }
          }}
        >
          <i className="ri-menu-line text-xl"></i>
        </button>
      </div>

      {/* Mobile Sidebar Overlay */}
      <div 
        id="sidebarOverlay" 
        className="md:hidden fixed inset-0 bg-black bg-opacity-50 z-20 hidden"
        onClick={() => {
          const sidebar = document.querySelector('.sidebar');
          const overlay = document.getElementById('sidebarOverlay');
          
          if (sidebar && overlay) {
            sidebar.classList.remove('active');
            sidebar.classList.add('hidden');
            overlay.classList.add('hidden');
            document.body.classList.remove('overflow-hidden');
          }
        }}
      ></div>
    </>
  );
};

export default Sidebar;
