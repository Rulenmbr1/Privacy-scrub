import { Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { UpgradePrompt } from "./UpgradePrompt";
import { ScrubButton } from "../ScrubButton";
import { useAuth } from "@/hooks/AuthProvider";

export interface Finding {
  id: number;
  website: string;
  riskLevel: "High" | "Medium" | "Low";
  foundDate: string;
  status: "Not Started" | "In Progress" | "Complete" | "Action Needed";
  exposedInfo: string[];
  progress: number;
  currentStep?: number;
  totalSteps?: number;
}

interface RedactedFindings {
  isRedacted: true;
  sitesFound: number;
  privacyScore: number;
  message: string;
}

interface RecentFindingsProps {
  limit?: number;
}

const StatusBadge = ({ status }: { status: Finding["status"] }) => {
  const getStatusInfo = (status: Finding["status"]) => {
    switch (status) {
      case "Not Started":
        return { icon: "ri-error-warning-line", color: "bg-error", text: "text-error" };
      case "In Progress":
        return { icon: "ri-time-line", color: "bg-warning", text: "text-warning" };
      case "Complete":
        return { icon: "ri-check-line", color: "bg-success", text: "text-success" };
      case "Action Needed":
        return { icon: "ri-error-warning-line", color: "bg-error", text: "text-error" };
      default:
        return { icon: "ri-information-line", color: "bg-primary", text: "text-primary" };
    }
  };

  const { icon, color, text } = getStatusInfo(status);

  return (
    <span className={`px-3 py-1 rounded-full ${color} bg-opacity-10 ${text} text-xs font-medium flex items-center`}>
      <i className={`${icon} mr-1`}></i>
      {status}
    </span>
  );
};

const RiskBadge = ({ level }: { level: Finding["riskLevel"] }) => {
  const getRiskColor = (level: Finding["riskLevel"]) => {
    switch (level) {
      case "High":
        return "bg-error text-error";
      case "Medium":
        return "bg-warning text-warning";
      case "Low":
        return "bg-success text-success";
      default:
        return "bg-primary text-primary";
    }
  };

  return (
    <span className={`ml-3 px-2 py-1 ${getRiskColor(level)} bg-opacity-10 rounded-md text-xs font-medium`}>
      {level} Risk
    </span>
  );
};

const ProgressBar = ({ progress }: { progress: number }) => {
  return (
    <div className="inline-block w-24 h-2 rounded-full bg-gray-200">
      <div
        className={`h-full rounded-full ${
          progress === 100
            ? "bg-success"
            : progress > 0
            ? "bg-warning"
            : "bg-primary"
        }`}
        style={{ width: `${progress}%` }}
      ></div>
    </div>
  );
};

const FindingItem = ({ finding }: { finding: Finding }) => {
  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden">
      <div className="p-5 border-b">
        <div className="flex items-start justify-between">
          <div>
            <div className="flex items-center">
              <h3 className="font-semibold">{finding.website}</h3>
              <RiskBadge level={finding.riskLevel} />
            </div>
            <p className="text-medium text-sm mt-1">Found {finding.foundDate}</p>
          </div>
          <div className="flex items-center">
            <StatusBadge status={finding.status} />
          </div>
        </div>
      </div>
      
      <div className="px-5 py-4">
        <h4 className="text-sm font-medium mb-2">Information Exposed:</h4>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-2 text-sm mb-4">
          {finding.exposedInfo.map((info, index) => (
            <div key={index} className="flex items-center">
              <i className="ri-check-line text-error mr-2"></i>
              <span>{info}</span>
            </div>
          ))}
        </div>
        
        <div className="flex items-center justify-between">
          <div>
            {finding.status === "Not Started" ? (
              <button 
                onClick={() => window.location.href = `/removal-guides/${finding.id}`} 
                className="text-blue-600 hover:text-blue-700 text-sm font-medium transition-colors"
              >
                Start Removal Process
              </button>
            ) : finding.status === "In Progress" ? (
              <button 
                onClick={() => window.location.href = `/removal-guides/${finding.id}`} 
                className="text-blue-600 hover:text-blue-700 text-sm font-medium transition-colors"
              >
                View Removal Guide
              </button>
            ) : (
              <button 
                onClick={() => window.location.href = `/removal-status`} 
                className="text-blue-600 hover:text-blue-700 text-sm font-medium transition-colors"
              >
                View Details
              </button>
            )}
          </div>
          <div className="space-x-2">
            {finding.status === "In Progress" ? (
              <span className="text-light text-sm">
                Step {finding.currentStep} of {finding.totalSteps}
              </span>
            ) : finding.status === "Complete" ? (
              <span className="text-light text-sm">Completed</span>
            ) : finding.status === "Not Started" ? (
              <span className="text-light text-sm">Not Started</span>
            ) : (
              <span className="text-light text-sm">Action Required</span>
            )}
            <ProgressBar progress={finding.progress} />
          </div>
        </div>
      </div>
    </div>
  );
};

const RecentFindings: React.FC<RecentFindingsProps> = ({ limit = 3 }) => {
  const { user } = useAuth();
  const { data: findings, isLoading, error } = useQuery({
    queryKey: ['/api/findings'],
    refetchInterval: false,
    refetchOnWindowFocus: false,
    staleTime: 0, // Always consider data stale so it refetches
  });

  // Debug logging
  console.log('RecentFindings - findings data:', findings);
  console.log('RecentFindings - isLoading:', isLoading);
  console.log('RecentFindings - error:', error);

  if (isLoading) {
    return (
      <div className="space-y-4">
        {[...Array(3)].map((_, index) => (
          <div key={index} className="bg-white rounded-xl shadow-sm p-6 animate-pulse">
            <div className="h-6 bg-gray-200 rounded w-1/3 mb-4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2 mb-6"></div>
            <div className="space-y-2">
              <div className="h-4 bg-gray-200 rounded"></div>
              <div className="h-4 bg-gray-200 rounded"></div>
              <div className="h-4 bg-gray-200 rounded w-3/4"></div>
            </div>
          </div>
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="bg-white rounded-xl shadow-sm p-6">
        <p className="text-error">Error loading findings. Please try again later.</p>
      </div>
    );
  }

  // Handle redacted results for unpaid users
  if (findings && !Array.isArray(findings) && (findings as any).isRedacted) {
    return (
      <div className="bg-white rounded-xl shadow-sm p-6">
        <h2 className="text-lg font-semibold mb-4">Search Results</h2>
        <div className="text-center py-8">
          <div className="bg-blue-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
            <i className="ri-search-line text-2xl text-blue-600"></i>
          </div>
          <h3 className="text-xl font-bold text-gray-900 mb-2">
            Your name was found on {(findings as any).sitesFound} websites
          </h3>
          <p className="text-gray-600 mb-2">Privacy Score: {(findings as any).privacyScore}%</p>
          <p className="text-gray-500 text-sm mb-6">{(findings as any).message}</p>
          <Link href="/checkout" className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors shadow-sm inline-flex items-center">
            <i className="ri-lock-unlock-line mr-2"></i>
            Upgrade to See Details & Remove Info
          </Link>
        </div>
      </div>
    );
  }

  if (!findings || !Array.isArray(findings) || findings.length === 0) {
    return (
      <div className="bg-white rounded-xl shadow-sm p-6 text-center">
        <i className="ri-file-search-line text-4xl text-light mb-2"></i>
        <h3 className="text-lg font-medium mb-2">No findings yet</h3>
        <p className="text-light mb-4">Start a scan to find your information across the web</p>
        <Link href="/new-search" className="px-5 py-2 bg-primary hover:bg-primary-dark text-white font-medium rounded-lg transition-colors shadow-sm inline-flex items-center">
          <i className="ri-search-line mr-2"></i>
          Start a New Scan
        </Link>
      </div>
    );
  }

  const displayedFindings = Array.isArray(findings) ? findings.slice(0, limit) : [];

  return (
    <>
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-4 gap-4">
        <h2 className="text-lg font-semibold">Recent Findings</h2>
        {user?.hasPaid && Array.isArray(findings) && findings.length > 0 && (
          <ScrubButton />
        )}
      </div>
      
      <div className="space-y-4">
        {displayedFindings.map((finding: Finding) => (
          <FindingItem key={finding.id} finding={finding} />
        ))}
      </div>
      
      {Array.isArray(findings) && findings.length > limit && (
        <div className="mt-4 text-center">
          <span 
            onClick={() => window.location.href = '/removal-status'} 
            className="text-blue-600 hover:text-blue-700 text-sm font-medium transition-colors cursor-pointer"
          >
            View All Findings
            <i className="ri-arrow-right-line ml-1"></i>
          </span>
        </div>
      )}
    </>
  );
};

export default RecentFindings;
