import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Loader2, Trash2, CheckCircle, XCircle, Clock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";

interface ScrubStatus {
  total: number;
  processing: number;
  completed: number;
  failed: number;
}

export function DataScrubber() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Query for scrub status
  const { data: scrubStatus, isLoading: statusLoading } = useQuery<ScrubStatus>({
    queryKey: ["/api/scrub/status"],
    refetchInterval: 2000, // Poll every 2 seconds when scrubbing is active
  });

  // Mutation to initiate scrub process
  const initiateScrub = useMutation({
    mutationFn: async () => {
      const response = await apiRequest("/api/scrub/initiate", { method: "POST" });
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Data Removal Started",
        description: data.message,
      });
      queryClient.invalidateQueries({ queryKey: ["/api/scrub/status"] });
      queryClient.invalidateQueries({ queryKey: ["/api/findings"] });
    },
    onError: (error: any) => {
      toast({
        title: "Failed to Start Removal",
        description: error.message || "An error occurred while starting the removal process",
        variant: "destructive",
      });
    },
  });

  const hasActiveProcess = scrubStatus && scrubStatus.processing > 0;
  const hasCompletedItems = scrubStatus && scrubStatus.completed > 0;
  const hasFailedItems = scrubStatus && scrubStatus.failed > 0;
  const totalProgress = scrubStatus 
    ? ((scrubStatus.completed + scrubStatus.failed) / scrubStatus.total) * 100 
    : 0;

  return (
    <Card className="w-full max-w-2xl">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Trash2 className="h-5 w-5" />
          Automated Data Removal
        </CardTitle>
        <CardDescription>
          Automatically remove your personal information from data broker websites.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Status Overview */}
        {scrubStatus && scrubStatus.total > 0 && (
          <div className="space-y-4">
            <div className="flex justify-between text-sm">
              <span>Overall Progress</span>
              <span>{Math.round(totalProgress)}% Complete</span>
            </div>
            <Progress value={totalProgress} className="w-full" />
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-blue-600">{scrubStatus.total}</div>
                <div className="text-xs text-muted-foreground">Total Sites</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-orange-600 flex items-center justify-center gap-1">
                  {scrubStatus.processing}
                  {hasActiveProcess && <Clock className="h-4 w-4" />}
                </div>
                <div className="text-xs text-muted-foreground">Processing</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600 flex items-center justify-center gap-1">
                  {scrubStatus.completed}
                  {hasCompletedItems && <CheckCircle className="h-4 w-4" />}
                </div>
                <div className="text-xs text-muted-foreground">Removed</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-red-600 flex items-center justify-center gap-1">
                  {scrubStatus.failed}
                  {hasFailedItems && <XCircle className="h-4 w-4" />}
                </div>
                <div className="text-xs text-muted-foreground">Failed</div>
              </div>
            </div>
          </div>
        )}

        {/* Action Button */}
        <div className="flex flex-col items-center space-y-4">
          <Button
            onClick={() => initiateScrub.mutate()}
            disabled={initiateScrub.isPending || hasActiveProcess || statusLoading}
            size="lg"
            className="w-full bg-red-600 hover:bg-red-700 text-white font-semibold py-3"
          >
            {initiateScrub.isPending ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Starting Removal...
              </>
            ) : hasActiveProcess ? (
              <>
                <Clock className="mr-2 h-4 w-4" />
                Removal in Progress
              </>
            ) : (
              <>
                <Trash2 className="mr-2 h-4 w-4" />
                SCRUB MY DATA
              </>
            )}
          </Button>

          {/* Status Messages */}
          {hasActiveProcess && (
            <div className="text-center space-y-2">
              <Badge variant="outline" className="bg-orange-50 text-orange-700 border-orange-200">
                <Clock className="mr-1 h-3 w-3" />
                Automated removal in progress
              </Badge>
              <p className="text-sm text-muted-foreground">
                We're automatically contacting websites to remove your data. This may take several minutes.
              </p>
            </div>
          )}

          {scrubStatus && scrubStatus.total > 0 && !hasActiveProcess && (
            <div className="text-center space-y-2">
              {totalProgress === 100 ? (
                <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                  <CheckCircle className="mr-1 h-3 w-3" />
                  Removal process completed
                </Badge>
              ) : (
                <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                  Removal process paused
                </Badge>
              )}
            </div>
          )}

          {scrubStatus && scrubStatus.total === 0 && (
            <p className="text-sm text-muted-foreground text-center">
              No data findings available for removal. Complete a search first to identify websites containing your information.
            </p>
          )}
        </div>

        {/* Information */}
        <div className="bg-blue-50 dark:bg-blue-950/20 p-4 rounded-lg">
          <h4 className="font-semibold text-blue-900 dark:text-blue-100 mb-2">
            How Automated Removal Works:
          </h4>
          <ul className="text-sm text-blue-800 dark:text-blue-200 space-y-1">
            <li>• Automatically contacts data broker websites</li>
            <li>• Submits removal requests on your behalf</li>
            <li>• Monitors removal status and retries if needed</li>
            <li>• Updates your privacy dashboard in real-time</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}