import { useEffect, useState } from 'react';
import { useLocation } from 'wouter';
import { CheckCircle, ArrowRight } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { apiRequest } from '@/lib/queryClient';
import { useAuth } from '@/hooks/useAuth';

export default function PaymentSuccess() {
  const [, setLocation] = useLocation();
  const [isVerifying, setIsVerifying] = useState(true);
  const [verificationError, setVerificationError] = useState<string | null>(null);
  const { refetch } = useAuth();

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const paymentIntentId = urlParams.get('payment_intent');
    const sessionId = urlParams.get('session_id');
    
    if (paymentIntentId || sessionId) {
      // Verify payment with backend
      const payload = sessionId ? { sessionId } : { paymentIntentId };
      
      apiRequest('POST', '/api/confirm-payment', payload)
        .then((res) => res.json())
        .then((data) => {
          if (data.success) {
            refetch(); // Refresh user data
            setIsVerifying(false);
          } else {
            setVerificationError(data.message || 'Payment verification failed');
            setIsVerifying(false);
          }
        })
        .catch((error) => {
          console.error('Payment verification error:', error);
          setVerificationError('Failed to verify payment');
          setIsVerifying(false);
        });
    } else {
      setVerificationError('Payment information not found');
      setIsVerifying(false);
    }
  }, [refetch]);

  if (isVerifying) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardContent className="p-6 text-center">
            <div className="animate-spin w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full mx-auto mb-4" />
            <p>Verifying your payment...</p>
          </CardContent>
        </Card>
      </div>
    );
  }

  if (verificationError) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="text-red-600">Payment Verification Failed</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-gray-600">{verificationError}</p>
            <Button onClick={() => setLocation('/checkout')} className="w-full">
              Try Again
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mb-4">
            <CheckCircle className="w-6 h-6 text-green-600" />
          </div>
          <CardTitle className="text-2xl text-green-600">Payment Successful!</CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-4">
          <p className="text-gray-600">
            Thank you for your purchase! You now have full access to Privacy Scrub.
          </p>
          <div className="bg-green-50 p-4 rounded-lg">
            <p className="text-sm text-green-800">
              You can now see detailed findings, access removal guides, and use the automated scrub feature.
            </p>
          </div>
          <Button onClick={() => setLocation('/dashboard')} className="w-full">
            Go to Dashboard
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}