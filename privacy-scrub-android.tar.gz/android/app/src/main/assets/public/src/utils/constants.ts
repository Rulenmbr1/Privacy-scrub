export const PEOPLE_SEARCH_SITES = [
  {
    name: "Spokeo",
    domain: "spokeo.com",
    removalUrl: "https://www.spokeo.com/optout",
    type: "background-check",
  },
  {
    name: "BeenVerified",
    domain: "beenverified.com",
    removalUrl: "https://www.beenverified.com/app/optout/search",
    type: "background-check",
  },
  {
    name: "WhitePages",
    domain: "whitepages.com",
    removalUrl: "https://www.whitepages.com/suppression-requests",
    type: "people-search",
  },
  {
    name: "Intelius",
    domain: "intelius.com",
    removalUrl: "https://www.intelius.com/optout",
    type: "background-check",
  },
  {
    name: "PeopleFinders",
    domain: "peoplefinders.com",
    removalUrl: "https://www.peoplefinders.com/opt-out",
    type: "people-search",
  },
  {
    name: "PeopleSmart",
    domain: "peoplesmart.com",
    removalUrl: "https://www.peoplesmart.com/optout-go",
    type: "people-search",
  },
  {
    name: "TruthFinder",
    domain: "truthfinder.com",
    removalUrl: "https://www.truthfinder.com/opt-out/",
    type: "background-check",
  },
  {
    name: "USSearch",
    domain: "ussearch.com",
    removalUrl: "https://www.ussearch.com/opt-out/submit/",
    type: "people-search",
  },
  {
    name: "Radaris",
    domain: "radaris.com",
    removalUrl: "https://radaris.com/control/privacy",
    type: "people-search",
  },
  {
    name: "ZabaSearch",
    domain: "zabasearch.com",
    removalUrl: "https://www.zabasearch.com/block-records/",
    type: "people-search",
  },
  {
    name: "MyLife",
    domain: "mylife.com",
    removalUrl: "https://www.mylife.com/privacy-policy",
    type: "people-search",
  }
];

export const RISK_LEVELS = {
  HIGH: "High",
  MEDIUM: "Medium",
  LOW: "Low"
};

export const STATUS_TYPES = {
  NOT_STARTED: "Not Started",
  IN_PROGRESS: "In Progress",
  COMPLETE: "Complete",
  ACTION_NEEDED: "Action Needed"
};

export const COMMON_EXPOSED_INFO = [
  "Full Name",
  "Phone Number",
  "Home Address",
  "Email Address",
  "Age",
  "Date of Birth",
  "Previous Addresses",
  "Relatives",
  "Social Media Profiles",
  "Employment History",
  "Education History",
  "Court Records",
  "Criminal Records",
  "Property Records",
  "Marriage Records",
  "Divorce Records"
];
