import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { useLocation } from "wouter";

// Simple search schema with added age field
const searchSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  age: z.string().optional().or(z.literal("")),
  email: z.string().email("Please enter a valid email").optional().or(z.literal("")),
  city: z.string().optional().or(z.literal("")),
  state: z.string().optional(),
  phone: z.string().optional().or(z.literal("")),
  incorrectInfo: z.boolean().default(false)
});

type SearchFormValues = z.infer<typeof searchSchema>;

const states = [
  { value: "AL", label: "Alabama" },
  { value: "AK", label: "Alaska" },
  { value: "AZ", label: "Arizona" },
  { value: "AR", label: "Arkansas" },
  { value: "CA", label: "California" },
  { value: "CO", label: "Colorado" },
  { value: "CT", label: "Connecticut" },
  { value: "DE", label: "Delaware" },
  { value: "FL", label: "Florida" },
  { value: "GA", label: "Georgia" },
  { value: "HI", label: "Hawaii" },
  { value: "ID", label: "Idaho" },
  { value: "IL", label: "Illinois" },
  { value: "IN", label: "Indiana" },
  { value: "IA", label: "Iowa" },
  { value: "KS", label: "Kansas" },
  { value: "KY", label: "Kentucky" },
  { value: "LA", label: "Louisiana" },
  { value: "ME", label: "Maine" },
  { value: "MD", label: "Maryland" },
  { value: "MA", label: "Massachusetts" },
  { value: "MI", label: "Michigan" },
  { value: "MN", label: "Minnesota" },
  { value: "MS", label: "Mississippi" },
  { value: "MO", label: "Missouri" },
  { value: "MT", label: "Montana" },
  { value: "NE", label: "Nebraska" },
  { value: "NV", label: "Nevada" },
  { value: "NH", label: "New Hampshire" },
  { value: "NJ", label: "New Jersey" },
  { value: "NM", label: "New Mexico" },
  { value: "NY", label: "New York" },
  { value: "NC", label: "North Carolina" },
  { value: "ND", label: "North Dakota" },
  { value: "OH", label: "Ohio" },
  { value: "OK", label: "Oklahoma" },
  { value: "OR", label: "Oregon" },
  { value: "PA", label: "Pennsylvania" },
  { value: "RI", label: "Rhode Island" },
  { value: "SC", label: "South Carolina" },
  { value: "SD", label: "South Dakota" },
  { value: "TN", label: "Tennessee" },
  { value: "TX", label: "Texas" },
  { value: "UT", label: "Utah" },
  { value: "VT", label: "Vermont" },
  { value: "VA", label: "Virginia" },
  { value: "WA", label: "Washington" },
  { value: "WV", label: "West Virginia" },
  { value: "WI", label: "Wisconsin" },
  { value: "WY", label: "Wyoming" },
];

const NewSearch = () => {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [showIncorrectInfo, setShowIncorrectInfo] = useState(false);
  
  const { register, handleSubmit, watch, setValue, formState: { errors } } = useForm<SearchFormValues>({
    resolver: zodResolver(searchSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      age: "",
      email: "",
      city: "",
      state: "",
      phone: "",
      incorrectInfo: false
    }
  });

  const incorrectInfo = watch("incorrectInfo");

  const searchMutation = useMutation({
    mutationFn: (data: SearchFormValues) => {
      return apiRequest("POST", "/api/search", data);
    },
    onSuccess: async (response) => {
      const data = await response.json();
      toast({
        title: "Search initiated",
        description: "We're scanning for your information across the web.",
      });
      queryClient.invalidateQueries({ queryKey: ['/api/findings'] });
      navigate('/removal-status');
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to start search. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: SearchFormValues) => {
    searchMutation.mutate(data);
  };

  return (
    <div className="px-4 md:px-8 py-6">
      <header className="mb-8">
        <h1 className="text-2xl font-bold">Privacy Scrub Search</h1>
        <p className="text-muted-foreground mt-1">Search and remove your data from people search sites and background check services</p>
      </header>

      <div className="bg-card rounded-xl shadow-sm mb-6 p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold">Search Form</h2>
          <div className="flex items-center">
            <label htmlFor="incorrectInfo" className="text-sm font-medium mr-3">Found incorrect information?</label>
            <input 
              type="checkbox" 
              id="incorrectInfo" 
              className="h-4 w-4 rounded border-gray-300 text-primary focus:ring-primary"
              onChange={(e) => setValue("incorrectInfo", e.target.checked)}
              checked={incorrectInfo}
            />
          </div>
        </div>
        
        <div className="bg-lighter p-4 rounded-lg mb-4">
          <div className="flex items-start">
            <i className="ri-information-line text-primary mt-1 mr-2 text-lg"></i>
            <p className="text-sm">Enter your information below to search across 50+ people search and background check websites. We'll help you remove or correct your personal data to protect your privacy.</p>
          </div>
        </div>
        
        <form className="space-y-4" onSubmit={handleSubmit(onSubmit)}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="firstName" className="block text-sm font-medium text-medium mb-1">First Name *</label>
              <input 
                type="text" 
                id="firstName" 
                className={`w-full px-4 py-2 border ${errors.firstName ? 'border-error' : 'border-gray-300'} rounded-lg focus:ring-2 focus:ring-primary focus:border-primary`} 
                placeholder="Enter your first name"
                {...register("firstName")}
              />
              {errors.firstName && (
                <p className="mt-1 text-xs text-error">{errors.firstName.message}</p>
              )}
            </div>
            
            <div>
              <label htmlFor="lastName" className="block text-sm font-medium text-medium mb-1">Last Name *</label>
              <input 
                type="text" 
                id="lastName"
                className={`w-full px-4 py-2 border ${errors.lastName ? 'border-error' : 'border-gray-300'} rounded-lg focus:ring-2 focus:ring-primary focus:border-primary`} 
                placeholder="Enter your last name" 
                {...register("lastName")}
              />
              {errors.lastName && (
                <p className="mt-1 text-xs text-error">{errors.lastName.message}</p>
              )}
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label htmlFor="age" className="block text-sm font-medium text-medium mb-1">Age</label>
              <input 
                type="number" 
                id="age" 
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary" 
                placeholder="Enter your age" 
                {...register("age")}
              />
            </div>
          
            <div>
              <label htmlFor="city" className="block text-sm font-medium text-medium mb-1">City</label>
              <input 
                type="text" 
                id="city" 
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary" 
                placeholder="Enter your city" 
                {...register("city")}
              />
            </div>
            
            <div>
              <label htmlFor="state" className="block text-sm font-medium text-medium mb-1">State</label>
              <select 
                id="state" 
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
                {...register("state")}
              >
                <option value="">Select state</option>
                {states.map((state) => (
                  <option key={state.value} value={state.value}>
                    {state.label}
                  </option>
                ))}
              </select>
            </div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-medium mb-1">Email Address</label>
              <input 
                type="email" 
                id="email" 
                className={`w-full px-4 py-2 border ${errors.email ? 'border-error' : 'border-gray-300'} rounded-lg focus:ring-2 focus:ring-primary focus:border-primary`} 
                placeholder="We'll send removal instructions here" 
                {...register("email")}
              />
              {errors.email && (
                <p className="mt-1 text-xs text-error">{errors.email.message}</p>
              )}
            </div>
            
            <div>
              <label htmlFor="phone" className="block text-sm font-medium text-medium mb-1">Phone Number</label>
              <input 
                type="tel" 
                id="phone" 
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary" 
                placeholder="Optional contact number" 
                {...register("phone")}
              />
            </div>
          </div>
          
          {incorrectInfo && (
            <div className="mt-4 border-t pt-4">
              <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-4">
                <div className="flex">
                  <div className="flex-shrink-0">
                    <i className="ri-error-warning-line text-yellow-400"></i>
                  </div>
                  <div className="ml-3">
                    <p className="text-sm text-yellow-700">
                      We'll help you correct inaccurate information found on these sites. 
                      Please provide your correct information above.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}
          
          <div className="pt-4">
            <button 
              type="submit" 
              className="w-full md:w-auto px-6 py-3 bg-primary hover:bg-primary-dark text-white font-medium rounded-lg transition-colors shadow-sm flex items-center justify-center"
              disabled={searchMutation.isPending}
            >
              {searchMutation.isPending ? (
                <>
                  <i className="ri-loader-2-line animate-spin mr-2"></i>
                  Processing...
                </>
              ) : incorrectInfo ? (
                <>
                  <i className="ri-edit-line mr-2"></i>
                  Find & Correct My Info
                </>
              ) : (
                <>
                  <i className="ri-search-line mr-2"></i>
                  Search & Remove My Info
                </>
              )}
            </button>
          </div>
        </form>
        
        <div className="mt-6 pt-4 border-t">
          <h3 className="text-base font-medium mb-3">What we search for:</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
            <div className="flex items-center">
              <i className="ri-check-line text-primary mr-2"></i>
              Full name
            </div>
            <div className="flex items-center">
              <i className="ri-check-line text-primary mr-2"></i>
              Age and DOB
            </div>
            <div className="flex items-center">
              <i className="ri-check-line text-primary mr-2"></i>
              Current address
            </div>
            <div className="flex items-center">
              <i className="ri-check-line text-primary mr-2"></i>
              Past addresses
            </div>
            <div className="flex items-center">
              <i className="ri-check-line text-primary mr-2"></i>
              Phone numbers
            </div>
            <div className="flex items-center">
              <i className="ri-check-line text-primary mr-2"></i>
              Email addresses
            </div>
            <div className="flex items-center">
              <i className="ri-check-line text-primary mr-2"></i>
              Family members
            </div>
            <div className="flex items-center">
              <i className="ri-check-line text-primary mr-2"></i>
              Court records
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NewSearch;
