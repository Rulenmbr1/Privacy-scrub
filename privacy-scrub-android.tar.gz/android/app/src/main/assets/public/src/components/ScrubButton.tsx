import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Loader2, Trash2, CheckCircle, AlertCircle } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/hooks/AuthProvider";

export function ScrubButton() {
  const { toast } = useToast();
  const { user } = useAuth();
  const queryClient = useQueryClient();
  const [scrubProgress, setScrubProgress] = useState(0);
  const [isProcessing, setIsProcessing] = useState(false);
  const [processedCount, setProcessedCount] = useState(0);
  const [totalCount, setTotalCount] = useState(0);

  const initiateScrub = useMutation({
    mutationFn: async () => {
      const response = await fetch("/api/scrub/initiate", {
        method: "POST",
        credentials: "include",
      });
      
      if (!response.ok) {
        const error = await response.json();
        throw new Error(error.message || "Failed to start data removal");
      }
      
      return response.json();
    },
    onSuccess: (data) => {
      toast({
        title: "Data Removal Started",
        description: data.message,
      });
      
      // Start simulated progress
      setIsProcessing(true);
      setScrubProgress(0);
      setProcessedCount(0);
      setTotalCount(data.totalSites || 5);
      
      // Simulate progress updates
      simulateProgress(data.totalSites || 5);
      
      // Refresh findings after completion
      setTimeout(() => {
        queryClient.invalidateQueries({ queryKey: ["/api/findings"] });
      }, 8000);
    },
    onError: (error: any) => {
      toast({
        title: "Failed to Start Removal",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  const simulateProgress = (total: number) => {
    let processed = 0;
    const interval = setInterval(() => {
      processed += 1;
      setProcessedCount(processed);
      setScrubProgress((processed / total) * 100);
      
      if (processed >= total) {
        clearInterval(interval);
        setIsProcessing(false);
        toast({
          title: "Data Removal Complete",
          description: `Successfully removed data from ${processed} websites`,
        });
      }
    }, 1500); // Process one site every 1.5 seconds
  };

  if (!user?.hasPaid) {
    return (
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Trash2 className="h-5 w-5" />
            Automated Removal
          </CardTitle>
          <CardDescription>
            Premium feature for automatic data removal
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Button 
            disabled 
            className="w-full" 
            variant="outline"
          >
            Upgrade Required
          </Button>
          <p className="text-sm text-muted-foreground mt-2 text-center">
            Available for paid accounts only
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full max-w-md">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Trash2 className="h-5 w-5" />
          Automated Removal
        </CardTitle>
        <CardDescription>
          Remove your data from all found websites
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {isProcessing && (
          <div className="space-y-3">
            <div className="flex justify-between text-sm">
              <span>Processing websites...</span>
              <span>{processedCount}/{totalCount}</span>
            </div>
            <Progress value={scrubProgress} className="w-full" />
            <Badge variant="outline" className="w-full justify-center">
              <Loader2 className="mr-1 h-3 w-3 animate-spin" />
              Removing data automatically
            </Badge>
          </div>
        )}

        {scrubProgress === 100 && !isProcessing && (
          <Badge variant="outline" className="w-full justify-center bg-green-50 text-green-700 border-green-200">
            <CheckCircle className="mr-1 h-3 w-3" />
            Removal completed successfully
          </Badge>
        )}

        <Button
          onClick={() => initiateScrub.mutate()}
          disabled={initiateScrub.isPending || isProcessing}
          className="w-full bg-red-600 hover:bg-red-700 text-white font-semibold"
          size="lg"
        >
          {initiateScrub.isPending ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Starting...
            </>
          ) : isProcessing ? (
            <>
              <AlertCircle className="mr-2 h-4 w-4" />
              Processing...
            </>
          ) : (
            <>
              <Trash2 className="mr-2 h-4 w-4" />
              SCRUB MY DATA
            </>
          )}
        </Button>

        <div className="bg-blue-50 dark:bg-blue-950/20 p-3 rounded-lg">
          <p className="text-xs text-blue-800 dark:text-blue-200">
            This will automatically contact all websites where your data was found and request removal.
          </p>
        </div>
      </CardContent>
    </Card>
  );
}