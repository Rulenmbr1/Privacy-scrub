import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";

// Updated schema with better validation
const searchSchema = z.object({
  firstName: z.string().min(1, "First name is required"),
  lastName: z.string().min(1, "Last name is required"),
  age: z.string().optional(),
  email: z.string().email("Please enter a valid email").or(z.literal("")).optional(),
  city: z.string().optional(),
  state: z.string().optional(),
});

type SearchFormValues = z.infer<typeof searchSchema>;

const states = [
  { value: "AL", label: "Alabama" },
  { value: "AK", label: "Alaska" },
  { value: "AZ", label: "Arizona" },
  { value: "AR", label: "Arkansas" },
  { value: "CA", label: "California" },
  { value: "CO", label: "Colorado" },
  { value: "CT", label: "Connecticut" },
  { value: "DE", label: "Delaware" },
  { value: "FL", label: "Florida" },
  { value: "GA", label: "Georgia" },
  { value: "HI", label: "Hawaii" },
  { value: "ID", label: "Idaho" },
  { value: "IL", label: "Illinois" },
  { value: "IN", label: "Indiana" },
  { value: "IA", label: "Iowa" },
  { value: "KS", label: "Kansas" },
  { value: "KY", label: "Kentucky" },
  { value: "LA", label: "Louisiana" },
  { value: "ME", label: "Maine" },
  { value: "MD", label: "Maryland" },
  { value: "MA", label: "Massachusetts" },
  { value: "MI", label: "Michigan" },
  { value: "MN", label: "Minnesota" },
  { value: "MS", label: "Mississippi" },
  { value: "MO", label: "Missouri" },
  { value: "MT", label: "Montana" },
  { value: "NE", label: "Nebraska" },
  { value: "NV", label: "Nevada" },
  { value: "NH", label: "New Hampshire" },
  { value: "NJ", label: "New Jersey" },
  { value: "NM", label: "New Mexico" },
  { value: "NY", label: "New York" },
  { value: "NC", label: "North Carolina" },
  { value: "ND", label: "North Dakota" },
  { value: "OH", label: "Ohio" },
  { value: "OK", label: "Oklahoma" },
  { value: "OR", label: "Oregon" },
  { value: "PA", label: "Pennsylvania" },
  { value: "RI", label: "Rhode Island" },
  { value: "SC", label: "South Carolina" },
  { value: "SD", label: "South Dakota" },
  { value: "TN", label: "Tennessee" },
  { value: "TX", label: "Texas" },
  { value: "UT", label: "Utah" },
  { value: "VT", label: "Vermont" },
  { value: "VA", label: "Virginia" },
  { value: "WA", label: "Washington" },
  { value: "WV", label: "West Virginia" },
  { value: "WI", label: "Wisconsin" },
  { value: "WY", label: "Wyoming" },
];

const SearchSection = () => {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [showIncorrectInfo, setShowIncorrectInfo] = useState(false);
  const [searchResults, setSearchResults] = useState<any>(null);
  
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<SearchFormValues>({
    resolver: zodResolver(searchSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      age: "",
      email: "",
      city: "",
      state: "",
    }
  });

  const searchMutation = useMutation({
    mutationFn: async (data: SearchFormValues) => {
      // Format the data before sending
      const formattedData = {
        firstName: data.firstName,
        lastName: data.lastName,
        age: data.age || "",
        email: data.email || "",
        city: data.city || "",
        state: data.state || "",
      };
      
      console.log("Submitting search data:", formattedData);
      return apiRequest("POST", "/api/search", formattedData);
    },
    onSuccess: async (response) => {
      const data = await response.json();
      console.log("Search response:", data);
      
      toast({
        title: "Search completed",
        description: "Results are displayed below.",
      });
      
      // Immediately fetch the updated findings
      try {
        const findingsResponse = await apiRequest("GET", "/api/findings");
        const findingsData = await findingsResponse.json();
        setSearchResults(findingsData);
        console.log("Updated findings:", findingsData);
      } catch (error) {
        console.error("Failed to fetch updated findings:", error);
      }
      
      // Also invalidate queries for other components
      queryClient.invalidateQueries({ queryKey: ['/api/findings'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard'] });
    },
    onError: async (error: any) => {
      console.error("Search error:", error);
      
      // Check if it's a payment required error (402 status or payment required message)
      if (error.message && (
        error.message.includes("402") || 
        error.message.includes("Payment required") ||
        error.message.includes("payment required") ||
        error.message.includes("additional search")
      )) {
        toast({
          title: "Payment Required",
          description: "Additional searches require upgrading to full access.",
        });
        // Redirect to checkout page after a brief delay
        setTimeout(() => {
          navigate('/checkout');
        }, 1500);
        return;
      }
      
      toast({
        title: "Search Error", 
        description: error.message || "Failed to start search. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = async (data: SearchFormValues) => {
    console.log("Form submitted with data:", data);
    try {
      await searchMutation.mutateAsync(data);
    } catch (error) {
      console.error("Search submission error:", error);
    }
  };

  const toggleIncorrectInfo = () => {
    setShowIncorrectInfo(!showIncorrectInfo);
  };

  return (
    <div>
      <div className="bg-white rounded-xl shadow-sm mb-6 p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-lg font-semibold">Find & Remove Your Personal Information</h2>
          <button 
            onClick={toggleIncorrectInfo}
            className="text-primary text-sm hover:underline"
          >
            {showIncorrectInfo ? "Hide Options" : "Found Incorrect Info?"}
          </button>
        </div>
      
      <div className="bg-lighter p-4 rounded-lg mb-4">
        <div className="flex items-start">
          <i className="ri-information-line text-primary mt-1 mr-2 text-lg"></i>
          <p className="text-sm">Enter your information below to search across 50+ people search and background check websites. We'll help you remove your personal data to protect your privacy.</p>
        </div>
      </div>
      
      <form className="space-y-4" onSubmit={(e) => {
        e.preventDefault();
        handleSubmit(onSubmit)(e);
      }}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="firstName" className="block text-sm font-medium text-medium mb-1">First Name *</label>
            <input 
              type="text" 
              id="firstName" 
              className={`w-full px-4 py-2 border ${errors.firstName ? 'border-error' : 'border-gray-300'} rounded-lg focus:ring-2 focus:ring-primary focus:border-primary`} 
              placeholder="Enter your first name"
              {...register("firstName")}
            />
            {errors.firstName && (
              <p className="mt-1 text-xs text-error">{errors.firstName.message}</p>
            )}
          </div>
          
          <div>
            <label htmlFor="lastName" className="block text-sm font-medium text-medium mb-1">Last Name *</label>
            <input 
              type="text" 
              id="lastName"
              className={`w-full px-4 py-2 border ${errors.lastName ? 'border-error' : 'border-gray-300'} rounded-lg focus:ring-2 focus:ring-primary focus:border-primary`} 
              placeholder="Enter your last name" 
              {...register("lastName")}
            />
            {errors.lastName && (
              <p className="mt-1 text-xs text-error">{errors.lastName.message}</p>
            )}
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label htmlFor="age" className="block text-sm font-medium text-medium mb-1">Age</label>
            <input 
              type="text" 
              id="age" 
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary" 
              placeholder="Enter your age" 
              {...register("age")}
            />
          </div>
        
          <div>
            <label htmlFor="city" className="block text-sm font-medium text-medium mb-1">City</label>
            <input 
              type="text" 
              id="city" 
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary" 
              placeholder="Enter your city" 
              {...register("city")}
            />
          </div>
          
          <div>
            <label htmlFor="state" className="block text-sm font-medium text-medium mb-1">State</label>
            <select 
              id="state" 
              className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary"
              {...register("state")}
            >
              <option value="">Select state</option>
              {states.map((state) => (
                <option key={state.value} value={state.value}>
                  {state.label}
                </option>
              ))}
            </select>
          </div>
        </div>
        
        {showIncorrectInfo && (
          <div className="mt-4 border-t pt-4">
            <h3 className="text-base font-medium mb-2">Found incorrect information?</h3>
            <p className="text-sm text-light mb-4">
              We can help you correct inaccurate information found on these sites. Please provide your correct information above and additional details below.
            </p>
            <div>
              <label htmlFor="email" className="block text-sm font-medium text-medium mb-1">Email Address</label>
              <input 
                type="email" 
                id="email" 
                className={`w-full px-4 py-2 border ${errors.email ? 'border-error' : 'border-gray-300'} rounded-lg focus:ring-2 focus:ring-primary focus:border-primary`} 
                placeholder="We'll send removal instructions here" 
                {...register("email")}
              />
              {errors.email && (
                <p className="mt-1 text-xs text-error">{errors.email.message}</p>
              )}
            </div>
          </div>
        )}
        
        <div className="pt-4">
          <button 
            type="button" 
            className="w-full md:w-auto px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg"
            disabled={searchMutation.isPending}
            onClick={() => {
              console.log("Direct button click triggered");
              const formData = {
                firstName: "Allen",
                lastName: "Drent",
                age: "",
                email: "",
                city: "",
                state: ""
              };
              onSubmit(formData);
            }}
          >
            {searchMutation.isPending ? "Processing..." : "Test Search Button"}
          </button>
        </div>
      </form>
      </div>

      {/* Display search results immediately after search */}
      {searchResults && searchResults.isRedacted && (
        <div className="bg-white rounded-xl shadow-sm p-6 mt-6">
          <h2 className="text-lg font-semibold mb-4">Search Results</h2>
          <div className="text-center py-8">
            <div className="bg-blue-50 rounded-full w-16 h-16 flex items-center justify-center mx-auto mb-4">
              <i className="ri-search-line text-2xl text-blue-600"></i>
            </div>
            <h3 className="text-xl font-bold text-gray-900 mb-2">
              Your name was found on {searchResults.sitesFound} websites
            </h3>
            <p className="text-gray-600 mb-2">Privacy Score: {searchResults.privacyScore}%</p>
            <p className="text-gray-500 text-sm mb-6">{searchResults.message}</p>
            <button 
              onClick={() => navigate('/checkout')}
              className="px-6 py-3 bg-blue-600 hover:bg-blue-700 text-white font-medium rounded-lg transition-colors shadow-sm inline-flex items-center"
            >
              <i className="ri-lock-unlock-line mr-2"></i>
              Upgrade to See Details & Remove Info
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default SearchSection;
