import { useParams, useLocation } from "wouter";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";

interface RemovalStep {
  id: number;
  title: string;
  description: string;
  isCompleted: boolean;
}

interface RemovalGuideDetail {
  id: number;
  website: string;
  riskLevel: "High" | "Medium" | "Low";
  foundDate: string;
  status: "Not Started" | "In Progress" | "Complete" | "Action Needed";
  exposedInfo: string[];
  progress: number;
  currentStep: number;
  totalSteps: number;
  steps: RemovalStep[];
  websiteUrl: string;
  removalUrl: string;
  removalEmail?: string;
  notes?: string;
}

const RemovalGuides = () => {
  const params = useParams();
  const findingId = params.id ? parseInt(params.id) : undefined;
  const [, navigate] = useLocation();
  const { toast } = useToast();
  
  const { data: guide, isLoading } = useQuery<RemovalGuideDetail>({
    queryKey: [`/api/removal-guides/${findingId}`],
    enabled: !!findingId,
  });

  const updateStepMutation = useMutation({
    mutationFn: ({ stepId, completed }: { stepId: number; completed: boolean }) => {
      return apiRequest("POST", `/api/removal-guides/${findingId}/steps/${stepId}`, { completed });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/removal-guides', findingId] });
      queryClient.invalidateQueries({ queryKey: ['/api/findings'] });
      queryClient.invalidateQueries({ queryKey: ['/api/dashboard'] });
      
      toast({
        title: "Progress updated",
        description: "Your removal progress has been saved.",
      });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update progress. Please try again.",
        variant: "destructive",
      });
    },
  });

  if (!findingId) {
    return (
      <div className="px-4 md:px-8 py-6">
        <header className="mb-8">
          <h1 className="text-2xl font-bold">Removal Guides</h1>
          <p className="text-light mt-1">Step-by-step instructions to remove your data</p>
        </header>
        
        <div className="bg-white rounded-xl shadow-sm p-10 text-center">
          <i className="ri-file-search-line text-5xl text-light mb-4"></i>
          <h2 className="text-xl font-medium mb-2">Select a finding</h2>
          <p className="text-light mb-6">Please select a finding from your removal status page</p>
          <button 
            onClick={() => navigate('/removal-status')}
            className="px-6 py-3 bg-primary hover:bg-primary-dark text-white font-medium rounded-lg transition-colors shadow-sm"
          >
            View Findings
          </button>
        </div>
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="px-4 md:px-8 py-6">
        <header className="mb-8">
          <h1 className="text-2xl font-bold">Removal Guide</h1>
          <p className="text-light mt-1">Loading...</p>
        </header>
        
        <div className="animate-pulse">
          <div className="bg-white rounded-xl shadow-sm mb-6 p-6">
            <div className="h-8 bg-gray-200 rounded w-1/3 mb-4"></div>
            <div className="h-4 bg-gray-200 rounded w-1/2 mb-6"></div>
            <div className="space-y-4">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="h-20 bg-gray-200 rounded"></div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!guide) {
    return (
      <div className="px-4 md:px-8 py-6">
        <header className="mb-8">
          <h1 className="text-2xl font-bold">Removal Guide</h1>
          <p className="text-light mt-1">Guide not found</p>
        </header>
        
        <div className="bg-white rounded-xl shadow-sm p-10 text-center">
          <i className="ri-error-warning-line text-5xl text-error mb-4"></i>
          <h2 className="text-xl font-medium mb-2">Guide Not Found</h2>
          <p className="text-light mb-6">The requested removal guide could not be found</p>
          <button 
            onClick={() => navigate('/removal-status')}
            className="px-6 py-3 bg-primary hover:bg-primary-dark text-white font-medium rounded-lg transition-colors shadow-sm"
          >
            Back to Findings
          </button>
        </div>
      </div>
    );
  }

  const handleStepComplete = (stepId: number, isCompleted: boolean) => {
    updateStepMutation.mutate({ stepId, completed: !isCompleted });
  };

  return (
    <div className="px-4 md:px-8 py-6">
      <header className="mb-8">
        <div className="flex items-center">
          <button 
            onClick={() => navigate('/removal-status')}
            className="mr-3 p-2 rounded-full hover:bg-gray-200 transition-colors"
          >
            <i className="ri-arrow-left-line text-medium"></i>
          </button>
          <div>
            <h1 className="text-2xl font-bold">Removal Guide: {guide.website}</h1>
            <p className="text-light mt-1">Follow these steps to remove your information</p>
          </div>
        </div>
      </header>

      <div className="bg-white rounded-xl shadow-sm mb-6 p-6">
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-6">
          <div className="flex items-center mb-3 md:mb-0">
            <h2 className="text-lg font-semibold mr-3">{guide.website}</h2>
            <span className={`px-2 py-1 rounded-md text-xs font-medium 
              ${guide.riskLevel === 'High' ? 'bg-error bg-opacity-10 text-error' : 
              guide.riskLevel === 'Medium' ? 'bg-warning bg-opacity-10 text-warning' : 
              'bg-success bg-opacity-10 text-success'}`}>
              {guide.riskLevel} Risk
            </span>
          </div>
          
          <div className="flex items-center space-x-3">
            <div className="text-sm">
              <span className="text-medium">Overall Progress: </span>
              <span className="font-medium">{guide.progress}%</span>
            </div>
            <div className="w-32 h-2 rounded-full bg-gray-200">
              <div 
                className={`h-full rounded-full ${
                  guide.progress === 100 ? "bg-success" : 
                  guide.progress > 0 ? "bg-warning" : 
                  "bg-primary"
                }`} 
                style={{ width: `${guide.progress}%` }}
              ></div>
            </div>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
          <div className="border rounded-lg p-4">
            <h3 className="font-medium mb-2">Information Exposed</h3>
            <ul className="space-y-1 text-sm text-medium">
              {guide.exposedInfo.map((info, index) => (
                <li key={index} className="flex items-center">
                  <i className="ri-check-line text-error mr-2"></i>
                  {info}
                </li>
              ))}
            </ul>
          </div>
          
          <div className="border rounded-lg p-4">
            <h3 className="font-medium mb-2">Website Details</h3>
            <ul className="space-y-1 text-sm text-medium">
              <li className="flex items-center">
                <i className="ri-global-line mr-2 text-primary"></i>
                <a 
                  href={guide.websiteUrl} 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-primary hover:underline"
                >
                  Visit Website
                </a>
              </li>
              {guide.removalEmail && (
                <li className="flex items-center">
                  <i className="ri-mail-line mr-2 text-primary"></i>
                  <a 
                    href={`mailto:${guide.removalEmail}`}
                    className="text-primary hover:underline"
                  >
                    {guide.removalEmail}
                  </a>
                </li>
              )}
            </ul>
          </div>
          
          <div className="border rounded-lg p-4">
            <h3 className="font-medium mb-2">Status Information</h3>
            <div className="space-y-2 text-sm text-medium">
              <div className="flex items-center justify-between">
                <span>Current Status:</span>
                <span className={`px-2 py-1 rounded-full text-xs font-medium 
                  ${guide.status === 'Complete' ? 'bg-success bg-opacity-10 text-success' : 
                  guide.status === 'In Progress' ? 'bg-warning bg-opacity-10 text-warning' : 
                  'bg-error bg-opacity-10 text-error'}`}>
                  {guide.status}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span>Found Date:</span>
                <span>{guide.foundDate}</span>
              </div>
              <div className="flex items-center justify-between">
                <span>Current Step:</span>
                <span>{guide.currentStep} of {guide.totalSteps}</span>
              </div>
            </div>
          </div>
        </div>
        
        {guide.notes && (
          <div className="bg-lighter p-4 rounded-lg mb-6">
            <div className="flex items-start">
              <i className="ri-information-line text-primary mt-1 mr-2"></i>
              <div>
                <h3 className="font-medium mb-1">Important Notes</h3>
                <p className="text-sm text-medium">{guide.notes}</p>
              </div>
            </div>
          </div>
        )}
        
        <div className="mt-6">
          <h3 className="text-lg font-semibold mb-4">Removal Steps</h3>
          
          <div className="space-y-6">
            {guide.steps.map((step, index) => (
              <div key={step.id} className="relative">
                <div className="flex">
                  <div className="flex flex-col items-center mr-4">
                    <div className={`h-10 w-10 rounded-full flex items-center justify-center font-bold ${
                      step.isCompleted || index === 0 ? 'bg-success text-white' : 'bg-primary text-white'
                    }`}>
                      {step.isCompleted || index === 0 ? <i className="ri-check-line"></i> : index + 1}
                    </div>
                    {index < guide.steps.length - 1 && (
                      <div className={`h-full w-0.5 mt-2 ${
                        step.isCompleted || index === 0 ? 'bg-success' : 'bg-gray-200'
                      }`}></div>
                    )}
                  </div>
                  <div className="pb-6 flex-1">
                    <div className="flex items-center justify-between">
                      <h4 className="font-medium text-base">{step.title}</h4>
                      <button 
                        onClick={() => handleStepComplete(step.id, step.isCompleted)}
                        className={`px-3 py-1 rounded-lg text-xs font-medium ${
                          step.isCompleted || index === 0
                            ? 'bg-success bg-opacity-10 text-success' 
                            : 'bg-gray-200 text-medium hover:bg-gray-300'
                        }`}
                        disabled={updateStepMutation.isPending || index === 0}
                      >
                        {updateStepMutation.isPending ? (
                          <i className="ri-loader-2-line animate-spin"></i>
                        ) : (
                          step.isCompleted || index === 0 ? 'Completed' : 'Mark as Complete'
                        )}
                      </button>
                    </div>
                    <p className="text-light text-sm mt-1">{step.description}</p>
                    
                    {/* Add removal link to first step */}
                    {index === 0 && (
                      <div className="mt-3 bg-lighter p-3 rounded-md">
                        <a 
                          href={guide.removalUrl} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="flex items-center text-primary hover:underline font-medium"
                        >
                          <i className="ri-external-link-line mr-2"></i>
                          Visit Removal Page
                        </a>
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default RemovalGuides;
