import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useLocation } from "wouter";
import { registerSchema, RegisterInput } from "@shared/schema";
import { Link } from "wouter";
import { useAuth } from "@/hooks/AuthProvider";

const Register = () => {
  const [, navigate] = useLocation();
  const { register: registerUser, registerLoading } = useAuth();

  const { register, handleSubmit, formState: { errors } } = useForm<RegisterInput>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: "",
      email: "",
      password: "",
      confirmPassword: ""
    }
  });

  const onSubmit = (data: RegisterInput) => {
    registerUser(data);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="w-full max-w-md">
        <div className="bg-card rounded-xl shadow-md p-8">
          <div className="text-center mb-8">
            <div className="flex justify-center mb-4">
              <div className="inline-flex items-center justify-center h-16 w-16 rounded-full bg-primary bg-opacity-10">
                <i className="ri-user-add-line text-primary text-3xl"></i>
              </div>
            </div>
            <h1 className="text-2xl font-bold text-foreground">Create an Account</h1>
            <p className="text-muted-foreground mt-2">Join Privacy Scrub to protect your online privacy</p>
          </div>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div className="space-y-1">
              <label htmlFor="username" className="text-sm font-medium text-foreground">
                Username
              </label>
              <input
                id="username"
                type="text"
                {...register("username")}
                className="w-full p-3 rounded-md border border-input bg-background text-foreground"
                placeholder="Choose a username"
              />
              {errors.username && (
                <p className="text-destructive text-sm">{errors.username.message}</p>
              )}
            </div>

            <div className="space-y-1">
              <label htmlFor="email" className="text-sm font-medium text-foreground">
                Email
              </label>
              <input
                id="email"
                type="email"
                {...register("email")}
                className="w-full p-3 rounded-md border border-input bg-background text-foreground"
                placeholder="Enter your email"
              />
              {errors.email && (
                <p className="text-destructive text-sm">{errors.email.message}</p>
              )}
            </div>

            <div className="space-y-1">
              <label htmlFor="password" className="text-sm font-medium text-foreground">
                Password
              </label>
              <input
                id="password"
                type="password"
                {...register("password")}
                className="w-full p-3 rounded-md border border-input bg-background text-foreground"
                placeholder="Create a password"
              />
              {errors.password && (
                <p className="text-destructive text-sm">{errors.password.message}</p>
              )}
            </div>

            <div className="space-y-1">
              <label htmlFor="confirmPassword" className="text-sm font-medium text-foreground">
                Confirm Password
              </label>
              <input
                id="confirmPassword"
                type="password"
                {...register("confirmPassword")}
                className="w-full p-3 rounded-md border border-input bg-background text-foreground"
                placeholder="Confirm your password"
              />
              {errors.confirmPassword && (
                <p className="text-destructive text-sm">{errors.confirmPassword.message}</p>
              )}
            </div>

            <button
              type="submit"
              disabled={registerLoading}
              className="w-full py-3 rounded-md bg-primary text-white font-medium hover:bg-primary/90 transition-colors disabled:opacity-70 mt-4"
            >
              {registerLoading ? (
                <div className="flex items-center justify-center">
                  <i className="ri-loader-2-line animate-spin mr-2"></i>
                  Creating account...
                </div>
              ) : (
                "Create Account"
              )}
            </button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-muted-foreground">
              Already have an account?{" "}
              <Link href="/login" className="text-primary hover:underline">
                Sign in
              </Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Register;