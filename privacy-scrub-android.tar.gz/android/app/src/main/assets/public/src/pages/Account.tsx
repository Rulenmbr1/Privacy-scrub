import { useState } from "react";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import AppLayout from "@/components/layout/AppLayout";

const Account = () => {
  const { user, logout } = useAuth();
  const { toast } = useToast();
  const [showLogout, setShowLogout] = useState(false);
  
  return (
    <AppLayout>
      <div className="py-6 max-w-4xl mx-auto">
        <h1 className="text-2xl font-bold mb-6">Account Settings</h1>
        
        <Tabs defaultValue="profile" className="w-full">
          <TabsList className="mb-6">
            <TabsTrigger value="profile">Profile</TabsTrigger>
            <TabsTrigger value="privacy">Privacy</TabsTrigger>
            <TabsTrigger value="notifications">Notifications</TabsTrigger>
          </TabsList>
          
          <TabsContent value="profile">
            <Card>
              <CardHeader>
                <CardTitle>Your Profile</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Username</label>
                    <div className="mt-1 flex items-center justify-between">
                      <p className="text-foreground font-medium">{user?.username || "Loading..."}</p>
                      <Button variant="outline" size="sm">Edit</Button>
                    </div>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Email</label>
                    <div className="mt-1 flex items-center justify-between">
                      <p className="text-foreground font-medium">{user?.email || "Not provided"}</p>
                      <Button variant="outline" size="sm">Change</Button>
                    </div>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium text-muted-foreground">Password</label>
                    <div className="mt-1 flex items-center justify-between">
                      <p className="text-foreground font-medium">••••••••</p>
                      <Button variant="outline" size="sm">Change</Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="privacy">
            <Card>
              <CardHeader>
                <CardTitle>Privacy Settings</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Data Retention</h3>
                        <p className="text-sm text-muted-foreground">Control how long we keep your search history</p>
                      </div>
                      <Button variant="outline">Configure</Button>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Data Export</h3>
                        <p className="text-sm text-muted-foreground">Download all your data</p>
                      </div>
                      <Button variant="outline">Export</Button>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Account Deletion</h3>
                        <p className="text-sm text-muted-foreground">Permanently delete your account and all data</p>
                      </div>
                      <Button variant="destructive">Delete Account</Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="notifications">
            <Card>
              <CardHeader>
                <CardTitle>Notification Preferences</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">Email Notifications</h3>
                        <p className="text-sm text-muted-foreground">Receive updates about removal progress</p>
                      </div>
                      <div className="flex items-center">
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input type="checkbox" className="sr-only peer" defaultChecked />
                          <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                        </label>
                      </div>
                    </div>
                  </div>
                  
                  <div>
                    <div className="flex items-center justify-between">
                      <div>
                        <h3 className="font-medium">New Findings Alerts</h3>
                        <p className="text-sm text-muted-foreground">Get notified when new personal information is found</p>
                      </div>
                      <div className="flex items-center">
                        <label className="relative inline-flex items-center cursor-pointer">
                          <input type="checkbox" className="sr-only peer" defaultChecked />
                          <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-blue-300 dark:peer-focus:ring-blue-800 rounded-full peer dark:bg-gray-700 peer-checked:after:translate-x-full rtl:peer-checked:after:-translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:start-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all dark:border-gray-600 peer-checked:bg-blue-600"></div>
                        </label>
                      </div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
        
        <Card className="mt-6">
          <CardHeader>
            <CardTitle>Account Actions</CardTitle>
          </CardHeader>
          <CardContent>
            {!showLogout ? (
              <Button 
                variant="destructive" 
                onClick={() => setShowLogout(true)}
              >
                Log Out
              </Button>
            ) : (
              <div className="bg-destructive/10 p-4 rounded-md">
                <p className="mb-4">Are you sure you want to log out?</p>
                <div className="flex space-x-2">
                  <Button 
                    variant="destructive"
                    onClick={() => logout()}
                  >
                    Yes, Log Out
                  </Button>
                  <Button 
                    variant="outline"
                    onClick={() => setShowLogout(false)}
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </AppLayout>
  );
};

export default Account;