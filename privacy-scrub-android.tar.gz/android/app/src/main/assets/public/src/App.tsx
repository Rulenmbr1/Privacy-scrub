import { Switch, Route, useLocation, Redirect } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/Dashboard";
import NewSearch from "@/pages/NewSearch";
import RemovalStatus from "@/pages/RemovalStatus";
import PrivacySettings from "@/pages/PrivacySettings";
import RemovalGuides from "@/pages/RemovalGuides";
import Account from "@/pages/Account";
import SimpleAccount from "@/pages/SimpleAccount";
import Login from "@/pages/Login";
import Register from "@/pages/Register";
import Debug from "@/pages/Debug";
import Checkout from "@/pages/Checkout";
import PaymentSuccess from "@/pages/PaymentSuccess";
import PaymentFailed from "@/pages/PaymentFailed";
import Admin from "@/pages/Admin";
import AdminPortal from "@/pages/AdminPortal";
import DataRemoval from "@/pages/DataRemoval";
import { AuthProvider } from "@/hooks/AuthProvider";
import { useAuth } from "@/hooks/useAuth";
import { ThemeProvider } from "@/components/ThemeProvider";

// Protected route component
const ProtectedRoute = ({ component: Component, ...rest }: any) => {
  const { isAuthenticated, isLoading } = useAuth();
  const [location] = useLocation();

  if (isLoading) {
    return <div className="flex h-screen items-center justify-center">Loading...</div>;
  }

  if (!isAuthenticated) {
    return <Redirect to={`/login?redirect=${encodeURIComponent(location)}`} />;
  }

  return <Component {...rest} />;
};

function Router() {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return <div className="flex h-screen items-center justify-center">Loading...</div>;
  }

  return (
    <Switch>
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route path="/admin-portal" component={AdminPortal} />
      
      {isAuthenticated ? (
        <>
          <Route path="/" component={Dashboard} />
          <Route path="/new-search" component={NewSearch} />
          <Route path="/removal-status" component={RemovalStatus} />
          <Route path="/removal-guides" component={RemovalGuides} />
          <Route path="/removal-guides/:id" component={RemovalGuides} />
          <Route path="/data-removal" component={DataRemoval} />
          <Route path="/account" component={Account} />
          <Route path="/checkout" component={Checkout} />
          <Route path="/payment-success" component={PaymentSuccess} />
          <Route path="/payment-failed" component={PaymentFailed} />
          <Route path="/admin" component={Admin} />
          <Route path="/debug" component={Debug} />
        </>
      ) : (
        <>
          <Route path="/admin" component={Admin} />
          <Route path="/">
            <Redirect to="/login" />
          </Route>
        </>
      )}
      
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <ThemeProvider defaultTheme="light">
        <AuthProvider>
          <TooltipProvider>
            <Router />
            <Toaster />
          </TooltipProvider>
        </AuthProvider>
      </ThemeProvider>
    </QueryClientProvider>
  );
}

export default App;
