import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Shield, DollarSign, Users, Trash2, Ban, AlertTriangle, UserPlus } from "lucide-react";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Label } from "@/components/ui/label";

interface User {
  id: number;
  username: string;
  email: string;
  hasPaid: boolean;
  isAdmin: boolean;
  isSuspended: boolean;
  createdAt: string;
}

export default function Admin() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [newPrice, setNewPrice] = useState("");
  const [newAccountForm, setNewAccountForm] = useState({
    username: "",
    email: "",
    password: ""
  });

  const { data: users = [], isLoading: usersLoading } = useQuery<User[]>({
    queryKey: ["/api/admin/users"],
  });

  const { data: currentPrice = "13.99", isLoading: priceLoading } = useQuery<string>({
    queryKey: ["/api/admin/price"],
  });

  const updatePriceMutation = useMutation({
    mutationFn: async (price: string) => {
      const response = await apiRequest("POST", "/api/admin/price", { price });
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Price Updated",
        description: "The app price has been successfully updated.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/price"] });
      setNewPrice("");
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update price",
        variant: "destructive",
      });
    },
  });

  const suspendUserMutation = useMutation({
    mutationFn: async (userId: number) => {
      const response = await apiRequest("POST", `/api/admin/users/${userId}/suspend`, {});
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "User Suspended",
        description: "The user account has been suspended.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to suspend user",
        variant: "destructive",
      });
    },
  });

  const deleteUserMutation = useMutation({
    mutationFn: async (userId: number) => {
      const response = await apiRequest("DELETE", `/api/admin/users/${userId}`, {});
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "User Deleted",
        description: "The user account has been permanently deleted.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete user",
        variant: "destructive",
      });
    },
  });

  const createPaidAccountMutation = useMutation({
    mutationFn: async (accountData: { username: string; email: string; password: string }) => {
      const response = await apiRequest("POST", "/api/admin/users/create-paid", accountData);
      return response.json();
    },
    onSuccess: () => {
      toast({
        title: "Paid Account Created",
        description: "The paid account has been successfully created.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      setNewAccountForm({ username: "", email: "", password: "" });
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create paid account",
        variant: "destructive",
      });
    },
  });

  const handleUpdatePrice = () => {
    if (!newPrice || isNaN(parseFloat(newPrice))) {
      toast({
        title: "Invalid Price",
        description: "Please enter a valid price amount.",
        variant: "destructive",
      });
      return;
    }
    updatePriceMutation.mutate(newPrice);
  };

  const handleSuspendUser = (userId: number, username: string) => {
    if (confirm(`Are you sure you want to suspend user: ${username}?`)) {
      suspendUserMutation.mutate(userId);
    }
  };

  const handleDeleteUser = (userId: number, username: string) => {
    if (confirm(`Are you sure you want to PERMANENTLY DELETE user: ${username}? This action cannot be undone.`)) {
      deleteUserMutation.mutate(userId);
    }
  };

  const handleCreatePaidAccount = () => {
    if (!newAccountForm.username || !newAccountForm.email || !newAccountForm.password) {
      toast({
        title: "Missing Information",
        description: "Please fill in all fields to create a paid account.",
        variant: "destructive",
      });
      return;
    }
    createPaidAccountMutation.mutate(newAccountForm);
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 flex items-center gap-2">
            <Shield className="h-8 w-8 text-blue-600" />
            Administration Panel
          </h1>
          <p className="text-gray-600 mt-2">Manage app settings, pricing, and user accounts</p>
        </div>

        {/* Admin Disclaimer */}
        <Alert className="mb-6 border-amber-200 bg-amber-50">
          <AlertTriangle className="h-4 w-4 text-amber-600" />
          <AlertDescription className="text-amber-800">
            <strong>Important Notice:</strong> As the administrator, you reserve the right to suspend or terminate any user account at any time for any reason. Users are subject to these terms upon registration and use of the service.
          </AlertDescription>
        </Alert>

        <Tabs defaultValue="pricing" className="space-y-6">
          <TabsList>
            <TabsTrigger value="pricing" className="flex items-center gap-2">
              <DollarSign className="h-4 w-4" />
              Pricing
            </TabsTrigger>
            <TabsTrigger value="users" className="flex items-center gap-2">
              <Users className="h-4 w-4" />
              User Management
            </TabsTrigger>
          </TabsList>

          <TabsContent value="pricing">
            <Card>
              <CardHeader>
                <CardTitle>App Pricing</CardTitle>
                <CardDescription>
                  Adjust the one-time payment amount for full app access
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center gap-4">
                  <div>
                    <label className="text-sm font-medium text-gray-700">Current Price</label>
                    <div className="text-2xl font-bold text-green-600">
                      ${priceLoading ? "..." : currentPrice}
                    </div>
                  </div>
                </div>

                <div className="flex items-end gap-3 max-w-md">
                  <div className="flex-1">
                    <label className="text-sm font-medium text-gray-700 block mb-1">
                      New Price ($)
                    </label>
                    <Input
                      type="number"
                      step="0.01"
                      placeholder="13.99"
                      value={newPrice}
                      onChange={(e) => setNewPrice(e.target.value)}
                    />
                  </div>
                  <Button 
                    onClick={handleUpdatePrice}
                    disabled={updatePriceMutation.isPending}
                  >
                    {updatePriceMutation.isPending ? "Updating..." : "Update Price"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="users">
            <div className="space-y-6">
              {/* Create Paid Account Section */}
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <UserPlus className="h-5 w-5" />
                    Create Paid Account
                  </CardTitle>
                  <CardDescription>
                    Create a new user account with immediate paid access
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div>
                      <Label htmlFor="username">Username</Label>
                      <Input
                        id="username"
                        placeholder="Enter username"
                        value={newAccountForm.username}
                        onChange={(e) => setNewAccountForm({
                          ...newAccountForm,
                          username: e.target.value
                        })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="email">Email</Label>
                      <Input
                        id="email"
                        type="email"
                        placeholder="Enter email"
                        value={newAccountForm.email}
                        onChange={(e) => setNewAccountForm({
                          ...newAccountForm,
                          email: e.target.value
                        })}
                      />
                    </div>
                    <div>
                      <Label htmlFor="password">Password</Label>
                      <Input
                        id="password"
                        type="password"
                        placeholder="Enter password"
                        value={newAccountForm.password}
                        onChange={(e) => setNewAccountForm({
                          ...newAccountForm,
                          password: e.target.value
                        })}
                      />
                    </div>
                  </div>
                  <Button 
                    onClick={handleCreatePaidAccount}
                    disabled={createPaidAccountMutation.isPending}
                    className="w-full md:w-auto"
                  >
                    {createPaidAccountMutation.isPending ? "Creating..." : "Create Paid Account"}
                  </Button>
                </CardContent>
              </Card>

              {/* Existing Users List */}
              <Card>
                <CardHeader>
                  <CardTitle>Existing Users</CardTitle>
                  <CardDescription>
                    View, suspend, or delete user accounts
                  </CardDescription>
                </CardHeader>
                <CardContent>
                {usersLoading ? (
                  <div className="space-y-4">
                    {[1, 2, 3].map((i) => (
                      <div key={i} className="animate-pulse">
                        <div className="h-16 bg-gray-200 rounded"></div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-4">
                    {users.map((user: User) => (
                      <div key={user.id} className="border rounded-lg p-4 bg-white">
                        <div className="flex items-center justify-between">
                          <div className="flex-1">
                            <div className="flex items-center gap-3">
                              <h3 className="font-medium text-gray-900">{user.username}</h3>
                              <div className="flex gap-2">
                                {user.isAdmin && (
                                  <Badge variant="outline" className="border-blue-200 text-blue-700">
                                    Admin
                                  </Badge>
                                )}
                                {user.hasPaid ? (
                                  <Badge variant="outline" className="border-green-200 text-green-700">
                                    Paid
                                  </Badge>
                                ) : (
                                  <Badge variant="outline" className="border-gray-200 text-gray-600">
                                    Free
                                  </Badge>
                                )}
                                {user.isSuspended && (
                                  <Badge variant="destructive">
                                    Suspended
                                  </Badge>
                                )}
                              </div>
                            </div>
                            <p className="text-sm text-gray-600">{user.email}</p>
                            <p className="text-xs text-gray-500">
                              Joined: {new Date(user.createdAt).toLocaleDateString()}
                            </p>
                          </div>
                          
                          {!user.isAdmin && (
                            <div className="flex gap-2">
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => handleSuspendUser(user.id, user.username)}
                                disabled={user.isSuspended || suspendUserMutation.isPending}
                              >
                                <Ban className="h-4 w-4 mr-1" />
                                Suspend
                              </Button>
                              <Button
                                size="sm"
                                variant="destructive"
                                onClick={() => handleDeleteUser(user.id, user.username)}
                                disabled={deleteUserMutation.isPending}
                              >
                                <Trash2 className="h-4 w-4 mr-1" />
                                Delete
                              </Button>
                            </div>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}