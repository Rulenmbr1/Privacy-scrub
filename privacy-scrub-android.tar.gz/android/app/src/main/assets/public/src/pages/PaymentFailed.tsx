import { useLocation } from 'wouter';
import { XCircle, ArrowLeft, CreditCard } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';

export default function PaymentFailed() {
  const [, setLocation] = useLocation();

  const urlParams = new URLSearchParams(window.location.search);
  const error = urlParams.get('error');
  const errorMessage = urlParams.get('error_description') || 'Your payment could not be processed at this time.';

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto w-12 h-12 bg-red-100 rounded-full flex items-center justify-center mb-4">
            <XCircle className="w-6 h-6 text-red-600" />
          </div>
          <CardTitle className="text-2xl text-red-600">Payment Failed</CardTitle>
        </CardHeader>
        <CardContent className="text-center space-y-4">
          <p className="text-gray-600">
            {errorMessage}
          </p>
          
          {error && (
            <div className="bg-red-50 p-4 rounded-lg">
              <p className="text-sm text-red-800">
                Error code: {error}
              </p>
            </div>
          )}

          <div className="bg-blue-50 p-4 rounded-lg">
            <p className="text-sm text-blue-800">
              Please check your payment information and try again. If the problem persists, contact your bank or try a different payment method.
            </p>
          </div>

          <div className="space-y-2">
            <Button onClick={() => setLocation('/checkout')} className="w-full">
              <CreditCard className="w-4 h-4 mr-2" />
              Try Payment Again
            </Button>
            <Button 
              variant="outline" 
              onClick={() => setLocation('/dashboard')} 
              className="w-full"
            >
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}