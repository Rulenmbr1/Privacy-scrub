import { useState } from "react";
import { Switch } from "@/components/ui/switch";

const PrivacySettings = () => {
  const [emailNotifications, setEmailNotifications] = useState(true);
  const [autoScan, setAutoScan] = useState(false);
  const [dataSharing, setDataSharing] = useState(false);

  return (
    <div className="px-4 md:px-8 py-6">
      <header className="mb-8">
        <h1 className="text-2xl font-bold">Privacy Settings</h1>
        <p className="text-light mt-1">Configure your privacy preferences</p>
      </header>

      <div className="bg-white rounded-xl shadow-sm mb-6 p-6">
        <h2 className="text-lg font-semibold mb-4">Notification Settings</h2>
        
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-medium">Email Notifications</h3>
              <p className="text-light text-sm">Receive updates about your privacy status and removal progress</p>
            </div>
            <Switch 
              checked={emailNotifications} 
              onCheckedChange={setEmailNotifications} 
            />
          </div>
          
          <div className="border-t pt-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-medium">Automatic Weekly Scans</h3>
                <p className="text-light text-sm">Automatically scan for new exposures of your information</p>
              </div>
              <Switch 
                checked={autoScan} 
                onCheckedChange={setAutoScan} 
              />
            </div>
          </div>
          
          <div className="border-t pt-4">
            <div className="flex items-center justify-between">
              <div>
                <h3 className="text-base font-medium">Data Sharing</h3>
                <p className="text-light text-sm">Allow anonymized data to be used for improving our services</p>
              </div>
              <Switch 
                checked={dataSharing} 
                onCheckedChange={setDataSharing} 
              />
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm mb-6 p-6">
        <h2 className="text-lg font-semibold mb-4">Data Protection</h2>
        
        <div className="space-y-6">
          <div>
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-base font-medium">Data Retention</h3>
              <span className="px-2 py-1 rounded-full bg-success bg-opacity-10 text-success text-xs font-medium">Active</span>
            </div>
            <p className="text-light text-sm mb-2">Control how long we store your search data and results</p>
            <div className="mt-2">
              <select className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary">
                <option value="30">30 days</option>
                <option value="90">90 days</option>
                <option value="180">180 days</option>
                <option value="365">1 year</option>
              </select>
            </div>
          </div>
          
          <div className="border-t pt-4">
            <h3 className="text-base font-medium mb-2">Delete Your Data</h3>
            <p className="text-light text-sm mb-4">Remove all your search history and personal information from our system</p>
            <button className="px-4 py-2 border border-error text-error hover:bg-error hover:text-white rounded-lg transition-colors">
              Delete My Data
            </button>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm p-6">
        <h2 className="text-lg font-semibold mb-4">Account Security</h2>
        
        <div className="space-y-4">
          <div>
            <h3 className="text-base font-medium mb-2">Change Password</h3>
            <p className="text-light text-sm mb-4">Update your account password regularly for better security</p>
            <button className="px-4 py-2 bg-primary text-white hover:bg-primary-dark rounded-lg transition-colors">
              Change Password
            </button>
          </div>
          
          <div className="border-t pt-4">
            <h3 className="text-base font-medium mb-2">Two-Factor Authentication</h3>
            <p className="text-light text-sm mb-4">Add an extra layer of security to your account</p>
            <button className="px-4 py-2 bg-primary text-white hover:bg-primary-dark rounded-lg transition-colors">
              Enable 2FA
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PrivacySettings;
