import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useLocation } from "wouter";
import { loginSchema, LoginInput } from "@shared/schema";
import { Link } from "wouter";
import { useAuth } from "@/hooks/AuthProvider";

const Login = () => {
  const [, navigate] = useLocation();
  const { login, loginLoading } = useAuth();

  const { register, handleSubmit, formState: { errors } } = useForm<LoginInput>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      email: "",
      password: ""
    }
  });

  const onSubmit = (data: LoginInput) => {
    login(data);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-background p-4">
      <div className="w-full max-w-md">
        <div className="bg-card rounded-xl shadow-md p-8">
          <div className="text-center mb-8">
            <div className="flex justify-center mb-4">
              <div className="inline-flex items-center justify-center h-16 w-16 rounded-full bg-primary bg-opacity-10">
                <i className="ri-shield-check-line text-primary text-3xl"></i>
              </div>
            </div>
            <h1 className="text-2xl font-bold text-foreground">Sign in to Privacy Scrub</h1>
            <p className="text-muted-foreground mt-2">Protect your personal information online</p>
          </div>

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
            <div className="space-y-1">
              <label htmlFor="email" className="text-sm font-medium text-foreground">
                Email
              </label>
              <input
                id="email"
                type="email"
                {...register("email")}
                className="w-full p-3 rounded-md border border-input bg-background text-foreground"
                placeholder="Enter your email"
              />
              {errors.email && (
                <p className="text-destructive text-sm">{errors.email.message}</p>
              )}
            </div>

            <div className="space-y-1">
              <div className="flex justify-between">
                <label htmlFor="password" className="text-sm font-medium text-foreground">
                  Password
                </label>
                <span className="text-sm text-primary hover:underline cursor-pointer">
                  Forgot password?
                </span>
              </div>
              <input
                id="password"
                type="password"
                {...register("password")}
                className="w-full p-3 rounded-md border border-input bg-background text-foreground"
                placeholder="Enter your password"
              />
              {errors.password && (
                <p className="text-destructive text-sm">{errors.password.message}</p>
              )}
            </div>

            <button
              type="submit"
              disabled={loginLoading}
              className="w-full py-3 rounded-md bg-primary text-white font-medium hover:bg-primary/90 transition-colors disabled:opacity-70"
            >
              {loginLoading ? (
                <div className="flex items-center justify-center">
                  <i className="ri-loader-2-line animate-spin mr-2"></i>
                  Signing in...
                </div>
              ) : (
                "Sign In"
              )}
            </button>
          </form>

          <div className="mt-6 text-center">
            <p className="text-muted-foreground">
              Don't have an account?{" "}
              <Link href="/register" className="text-primary hover:underline">
                Register
              </Link>
            </p>
            
            <div className="mt-4 p-3 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-md">
              <p className="text-xs text-yellow-800 dark:text-yellow-200 leading-relaxed">
                <strong>Beta Disclaimer:</strong> The automatic removal feature is in beta and may not function 100%. 
                You may still need to complete removal manually. We are not responsible for website host actions or denials.
              </p>
            </div>
            
            <div className="mt-4">
              <Link href="/admin-portal" className="text-xs text-gray-400 hover:text-gray-600">
                •
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;