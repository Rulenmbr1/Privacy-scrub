import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Lock, Shield, Eye, ArrowRight } from "lucide-react";
import { useLocation } from "wouter";

interface UpgradePromptProps {
  sitesFound: number;
  privacyScore: number;
}

export function UpgradePrompt({ sitesFound, privacyScore }: UpgradePromptProps) {
  const [, setLocation] = useLocation();

  const handleUpgrade = () => {
    setLocation("/checkout");
  };

  return (
    <div className="space-y-6">
      {/* Privacy Score Summary */}
      <Card className="border-amber-200 bg-amber-50">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2 text-amber-800">
              <Eye className="h-5 w-5" />
              Your Privacy Preview
            </CardTitle>
            <Badge variant="outline" className="border-amber-300 text-amber-700">
              Limited View
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-amber-800">{sitesFound}</div>
              <div className="text-sm text-amber-600">Sites Found</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-amber-800">{privacyScore}%</div>
              <div className="text-sm text-amber-600">Privacy Score</div>
            </div>
          </div>
          <p className="text-sm text-amber-700">
            We found your personal information on {sitesFound} websites. Your current privacy score is {privacyScore}%.
          </p>
        </CardContent>
      </Card>

      {/* Redacted Results */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lock className="h-5 w-5 text-gray-400" />
            Detailed Results
          </CardTitle>
          <CardDescription>
            Upgrade to see which specific websites have your information
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {[1, 2, 3].map((i) => (
              <div key={i} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-gray-300 rounded animate-pulse"></div>
                  <div>
                    <div className="w-32 h-4 bg-gray-300 rounded animate-pulse mb-1"></div>
                    <div className="w-24 h-3 bg-gray-200 rounded animate-pulse"></div>
                  </div>
                </div>
                <Lock className="h-4 w-4 text-gray-400" />
              </div>
            ))}
          </div>
          
          <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
            <div className="flex items-start gap-3">
              <Shield className="h-5 w-5 text-blue-600 mt-0.5" />
              <div className="flex-1">
                <h3 className="font-medium text-blue-900 mb-1">Unlock Complete Protection</h3>
                <p className="text-sm text-blue-700 mb-3">
                  Get detailed information about which websites have your data and step-by-step removal instructions.
                </p>
                <ul className="text-sm text-blue-700 space-y-1 mb-4">
                  <li>• See exactly which websites have your information</li>
                  <li>• Get detailed removal guides for each site</li>
                  <li>• Track your progress as you remove your data</li>
                  <li>• One-time payment, lifetime access</li>
                </ul>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Upgrade Button */}
      <Card className="border-blue-200 bg-blue-50">
        <CardContent className="p-6">
          <div className="text-center">
            <h3 className="text-lg font-semibold text-blue-900 mb-2">
              Ready to Take Control of Your Privacy?
            </h3>
            <p className="text-blue-700 mb-4">
              Unlock full access to your privacy report and removal tools for just $13.99
            </p>
            <Button 
              onClick={handleUpgrade}
              className="bg-blue-600 hover:bg-blue-700 text-white px-8"
              size="lg"
            >
              Upgrade Now - $13.99
              <ArrowRight className="ml-2 h-4 w-4" />
            </Button>
            <p className="text-xs text-blue-600 mt-2">
              One-time payment • Secure checkout • No subscription
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}