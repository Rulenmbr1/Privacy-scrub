import React, { useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/hooks/useAuth";

interface AppLayoutProps {
  children: React.ReactNode;
}

const AppLayout: React.FC<AppLayoutProps> = ({ children }) => {
  const { isAuthenticated, logout } = useAuth();
  const [location] = useLocation();

  useEffect(() => {
    // Add Remix Icon CSS
    const link = document.createElement('link');
    link.href = "https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css";
    link.rel = "stylesheet";
    document.head.appendChild(link);
  }, []);

  return (
    <div className="min-h-screen bg-background text-foreground">
      {isAuthenticated && (
        <header className="bg-white border-b border-gray-200 py-3">
          <div className="container mx-auto px-4 flex justify-between items-center">
            <div className="text-xl font-bold text-blue-600 cursor-pointer" onClick={() => window.location.href = '/'}>
              Privacy Scrub
            </div>
            <nav className="flex space-x-4 items-center">
              <div 
                className={`px-3 py-2 cursor-pointer ${location === '/' ? 'text-blue-600 font-medium' : 'text-gray-600 hover:text-blue-600'}`}
                onClick={() => window.location.href = '/'}
              >
                Dashboard
              </div>
              <div 
                className={`px-3 py-2 cursor-pointer ${location === '/removal-status' ? 'text-blue-600 font-medium' : 'text-gray-600 hover:text-blue-600'}`}
                onClick={() => window.location.href = '/removal-status'}
              >
                Removal Status
              </div>
              <div 
                className={`px-3 py-2 cursor-pointer ${location === '/removal-guides' ? 'text-blue-600 font-medium' : 'text-gray-600 hover:text-blue-600'}`}
                onClick={() => window.location.href = '/removal-guides'}
              >
                Guides
              </div>
              <div 
                className={`px-3 py-2 cursor-pointer ${location === '/account' ? 'text-blue-600 font-medium' : 'text-gray-600 hover:text-blue-600'}`}
                onClick={() => window.location.href = '/account'}
              >
                Account
              </div>
              <Button 
                variant="outline" 
                onClick={() => logout()}
                className="ml-2"
              >
                Log Out
              </Button>
            </nav>
          </div>
        </header>
      )}
      <main className="w-full p-4">
        <div className="container mx-auto">
          {children}
        </div>
      </main>
    </div>
  );
};

export default AppLayout;
