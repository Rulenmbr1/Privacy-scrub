import { useQuery } from "@tanstack/react-query";

interface PrivacyScoreProps {
  score?: number;
  sitesFound?: number;
  inProgress?: number;
  removed?: number;
  lastUpdated?: string;
}

const PrivacyScoreCard: React.FC<PrivacyScoreProps> = ({
  score = 0,
  sitesFound = 0,
  inProgress = 0, 
  removed = 0,
  lastUpdated = "Today"
}) => {
  // Calculate dashboard circle
  const calculateDashOffset = (score: number) => {
    const circumference = 2 * Math.PI * 36;
    return circumference - (circumference * score) / 100;
  };

  // Get status text based on score
  const getScoreStatus = (score: number) => {
    if (score >= 80) return "Excellent";
    if (score >= 60) return "Good";
    if (score >= 40) return "Fair";
    return "Poor";
  };

  // Get status color
  const getScoreColor = (score: number) => {
    if (score >= 80) return "#16a34a"; // success
    if (score >= 60) return "#f59e0b"; // warning
    if (score >= 40) return "#f97316"; // alert
    return "#ef4444"; // error
  };

  return (
    <div className="bg-card rounded-xl shadow-sm mb-6 p-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold mb-1">Your Privacy Score</h2>
          <p className="text-muted-foreground text-sm mb-4">Based on your exposure across the web</p>
        </div>
        <div className="bg-muted py-1 px-3 rounded-full text-xs font-medium text-muted-foreground">
          Last updated: {lastUpdated}
        </div>
      </div>
      
      <div className="flex flex-col md:flex-row items-start md:items-center gap-6">
        <div className="bg-muted rounded-lg p-4 w-full md:w-40 text-center">
          <div className="inline-flex items-center justify-center h-20 w-20 rounded-full text-white text-2xl font-bold relative" style={{ backgroundColor: getScoreColor(score) }}>
            <span>{score}%</span>
            <svg className="absolute inset-0" width="80" height="80">
              <circle cx="40" cy="40" r="36" fill="none" stroke="hsl(var(--muted))" strokeWidth="8" />
              <circle 
                cx="40" 
                cy="40" 
                r="36" 
                fill="none" 
                stroke={getScoreColor(score)} 
                strokeWidth="8" 
                strokeDasharray={`${2 * Math.PI * 36}`} 
                strokeDashoffset={calculateDashOffset(score)} 
                transform="rotate(-90 40 40)" 
              />
            </svg>
          </div>
          <p className="text-sm font-medium mt-2 text-foreground">Current Score</p>
        </div>
        
        <div className="flex-1 grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-muted rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-xs">Sites Found</p>
                <p className="text-2xl font-bold">{sitesFound}</p>
              </div>
              <div className="h-10 w-10 rounded-full bg-error bg-opacity-10 flex items-center justify-center">
                <i className="ri-radar-line text-error text-xl"></i>
              </div>
            </div>
          </div>
          
          <div className="bg-muted rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-xs">In Progress</p>
                <p className="text-2xl font-bold">{inProgress}</p>
              </div>
              <div className="h-10 w-10 rounded-full bg-warning bg-opacity-10 flex items-center justify-center">
                <i className="ri-time-line text-warning text-xl"></i>
              </div>
            </div>
          </div>
          
          <div className="bg-muted rounded-lg p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-muted-foreground text-xs">Removed</p>
                <p className="text-2xl font-bold">{removed}</p>
              </div>
              <div className="h-10 w-10 rounded-full bg-success bg-opacity-10 flex items-center justify-center">
                <i className="ri-check-line text-success text-xl"></i>
              </div>
            </div>
          </div>
        </div>
      </div>
      
      <div className="mt-4 border-t pt-4">
        <div className="flex justify-between items-center">
          <p className="text-sm font-medium text-foreground">
            {score < 80 ? (
              `Complete ${Math.ceil((80 - score) / 10)} more removals to reach "${getScoreStatus(80)}" status`
            ) : (
              "Your privacy protection is in good standing"
            )}
          </p>
          <button className="text-primary text-sm font-medium hover:underline">View Details</button>
        </div>
      </div>
    </div>
  );
};

export default PrivacyScoreCard;
